/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50553
Source Host           : localhost:3306
Source Database       : ad-network

Target Server Type    : MYSQL
Target Server Version : 50553
File Encoding         : 65001

Date: 2022-10-11 23:09:14
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `im_adsense`
-- ----------------------------
DROP TABLE IF EXISTS `im_adsense`;
CREATE TABLE `im_adsense` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `publishment_id` bigint(20) unsigned DEFAULT '0' COMMENT '流量主编号',
  `industry_id` bigint(20) unsigned DEFAULT '0' COMMENT '行业编号',
  `site_id` bigint(20) unsigned DEFAULT '0' COMMENT '站点编号',
  `channel_id` bigint(20) unsigned DEFAULT '0' COMMENT '频道编号',
  `size_id` bigint(20) unsigned DEFAULT '0' COMMENT '广告尺寸编号',
  `title` varchar(255) DEFAULT NULL COMMENT '名称',
  `origin` enum('UNION','LOCAL') DEFAULT 'UNION' COMMENT '类型{UNION:联盟广告}{LOCAL:本地广告}',
  `device` enum('PC','MOBILE') DEFAULT 'PC' COMMENT '设备{PC:电脑}{MOBILE:移动端}',
  `type` enum('SINGLE','MULTIGRAPH','POPUP','FLOAT','COUPLET') DEFAULT 'SINGLE' COMMENT '展现类型{SINGLE:单图}{MULTIGRAPH:多图}{POPUP:弹窗}{FLOAT:悬浮}{COUPLET:对联}',
  `charging` enum('DEFAULT','CPC','CPM','CPV','CPA','CPS') DEFAULT 'DEFAULT' COMMENT '广告类型{DEFAULT}{CPC}{CPM}{CPV}{CPA}{CPS}',
  `vacant` enum('EXCHANGE','DEFAULT','UNION','FIXED','HIDDEN') DEFAULT 'EXCHANGE' COMMENT '空闲设置{EXCHANGE:显示换量广告}{DEFAULT:显示默认广告}{UNION:显示联盟广告}{FIXED:固定占位符}{HIDDEN:隐藏广告位}',
  `locator` varchar(255) DEFAULT NULL COMMENT '默认广告地址',
  `image` varchar(255) DEFAULT NULL COMMENT '默认广告图片',
  `code` text COMMENT '联盟广告代码',
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `delete_time` datetime DEFAULT NULL,
  `state` enum('NORMAL','DISABLE') DEFAULT 'DISABLE' COMMENT '状态{NORMAL:投放中}{DISABLE:暂停投放}',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COMMENT='广告位';

-- ----------------------------
-- Records of im_adsense
-- ----------------------------
INSERT INTO `im_adsense` VALUES ('1', '10086', '3', '1', '1', '21', '单图换量', 'UNION', 'PC', 'SINGLE', 'DEFAULT', 'FIXED', null, null, '<script src=\"//pc.stgowan.com/pc/fixed-tf.js\" id=\"fixedid\" data=\"s=7512\"></script>', '2022-09-24 12:51:28', '2022-09-27 11:07:49', null, 'NORMAL');
INSERT INTO `im_adsense` VALUES ('2', '10086', '3', '1', '1', '21', '多图本地', 'UNION', 'PC', 'MULTIGRAPH', 'DEFAULT', 'DEFAULT', 'http://v2.me.yunduanchongqing.com/user/login/', 'http://adwords.me.yunduanchongqing.com/upload/20220926/9b4db057fda9b0fd820a79c9ab41edaa.png', null, '2022-09-24 12:55:16', '2022-09-26 21:26:23', null, 'NORMAL');
INSERT INTO `im_adsense` VALUES ('3', '10086', '3', '1', '1', '9', '悬浮联盟', 'UNION', 'PC', 'FLOAT', 'DEFAULT', 'UNION', null, null, '<div id=\"kp_box_479\" data-pid=\"479\">\r\n    <div class=\"_gnumici5vli\"></div>\r\n    <script type=\"text/javascript\">\r\n        (window.slotbydup = window.slotbydup || []).push({\r\n            id: \"u5883818\",\r\n            container: \"_gnumici5vli\",\r\n            async: true\r\n        });\r\n        alert(123)\r\n\'ALERT\', \'CONSOLE\', \'LOCATION\', \'COOKIE\', \'EVAL\'\r\n\'alert\', \'console\', \'location\', \'cookie\', \'eval\'\r\n    </script>\r\n    <script type=\"text/javascript\" src=\"//cpro.baidustatic.com/cpro/ui/cm.js\" async=\"async\" defer=\"defer\"></script>\r\n</div>', '2022-09-24 13:06:07', '2022-10-02 17:28:56', null, 'NORMAL');
INSERT INTO `im_adsense` VALUES ('4', '10086', '3', '1', '1', '12', '对联占位', 'UNION', 'PC', 'COUPLET', 'DEFAULT', 'FIXED', null, null, null, '2022-09-24 13:06:47', '2022-10-11 23:07:15', null, 'NORMAL');
INSERT INTO `im_adsense` VALUES ('5', '10086', '3', '1', '1', '9', '弹窗隐藏', 'UNION', 'PC', 'POPUP', 'DEFAULT', 'HIDDEN', null, null, null, '2022-09-24 13:07:20', '2022-10-02 17:27:35', null, 'NORMAL');
INSERT INTO `im_adsense` VALUES ('6', '10086', '3', '1', '1', '10', '悬浮换量', 'UNION', 'PC', 'FLOAT', 'DEFAULT', 'EXCHANGE', null, null, null, '2022-09-24 17:38:48', '2022-09-27 23:11:40', null, 'NORMAL');

-- ----------------------------
-- Table structure for `im_advertisement`
-- ----------------------------
DROP TABLE IF EXISTS `im_advertisement`;
CREATE TABLE `im_advertisement` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `type` enum('COMPANY','PERSONAL') DEFAULT 'COMPANY' COMMENT '类型{COMPANY:公司}{PERSONAL:个人}',
  `name` varchar(255) DEFAULT NULL COMMENT '公司名称/真实姓名',
  `licence` varchar(255) DEFAULT NULL COMMENT '营业执照编号/身份证编号',
  `licence_image` varchar(255) DEFAULT NULL COMMENT '营业执照附件/身份证附件',
  `corporation` varchar(255) DEFAULT NULL COMMENT '联系人',
  `mobile` varchar(255) DEFAULT NULL COMMENT '联系电话',
  `mail` varchar(255) DEFAULT NULL COMMENT '邮箱',
  `total` bigint(20) unsigned DEFAULT '0' COMMENT '总额',
  `balance` bigint(20) DEFAULT '0' COMMENT '余额',
  `frozen` bigint(20) DEFAULT '0' COMMENT '冻结金额',
  `wallet` enum('ALIPAY','WECHAT','USDT') DEFAULT 'USDT' COMMENT '钱包类型{支付宝:ALIPAY}{微信:WECHAT}{USDT:USDT}',
  `acount` varchar(255) DEFAULT NULL COMMENT '钱包地址',
  `audit` enum('INIT','WAIT','SUCCESS','FAILURE','STOP') DEFAULT 'INIT' COMMENT '审核状态{INIT:初始化}{WAIT:待审核}{SUCCESS:成功}{FAILURE:失败}{STOP:终止合作}',
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `delete_time` datetime DEFAULT NULL,
  `state` enum('NORMAL','DISABLE') DEFAULT 'DISABLE' COMMENT '状态{NORMAL:正常}{DISABLE:禁用}',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10089 DEFAULT CHARSET=utf8mb4 COMMENT='广告主主体';

-- ----------------------------
-- Records of im_advertisement
-- ----------------------------
INSERT INTO `im_advertisement` VALUES ('1', 'COMPANY', '公益科技有限公司', '913202007471896651', 'https://via.placeholder.com/200x200/ac68e1/fff/200x200.png?text=200x200', '公益', '13627666666', 'admin@admin.com', '0', '0', '0', 'USDT', '0x000000', 'SUCCESS', null, '2022-10-02 19:16:46', null, 'NORMAL');
INSERT INTO `im_advertisement` VALUES ('2', 'PERSONAL', '换量科技有限公司', '913202007471896652', 'https://via.placeholder.com/200x200/ac68e1/fff/200x200.png?text=200x200', '换量', '13627685888', 'manager@manager.com', '0', '0', '0', 'USDT', '0x000000', 'SUCCESS', '2022-09-20 11:57:46', '2022-10-02 19:16:46', null, 'NORMAL');
INSERT INTO `im_advertisement` VALUES ('10086', 'PERSONAL', 'ad1', '913202007471896653', 'https://via.placeholder.com/200x200/ac68e1/fff/200x200.png?text=200x200', 'ad1', '13627685888', 'test1@test.com', '10000000', '10000000', '0', 'USDT', '0x000000', 'SUCCESS', '2022-09-20 11:57:46', '2022-10-11 22:58:11', null, 'NORMAL');
INSERT INTO `im_advertisement` VALUES ('10087', 'COMPANY', 'ad2', '913202007471896654', 'https://via.placeholder.com/200x200/ac68e1/fff/200x200.png?text=200x200', 'ad2', '13627685888', 'test2@test.com', '0', '0', '0', 'USDT', '0x000000', 'SUCCESS', '2022-09-20 11:57:46', '2022-10-02 19:16:46', null, 'NORMAL');
INSERT INTO `im_advertisement` VALUES ('10088', 'COMPANY', 'ad3', '913202007471896655', 'https://via.placeholder.com/200x200/ac68e1/fff/200x200.png?text=200x200', 'ad3', '13627685888', 'test3@test.com', '0', '0', '0', 'USDT', '0x000000', 'SUCCESS', '2022-09-20 11:57:46', '2022-10-02 19:16:46', null, 'NORMAL');

-- ----------------------------
-- Table structure for `im_advertiser`
-- ----------------------------
DROP TABLE IF EXISTS `im_advertiser`;
CREATE TABLE `im_advertiser` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `advertisement_id` bigint(20) unsigned DEFAULT NULL,
  `role_id` int(11) unsigned DEFAULT '0' COMMENT '角色编号',
  `role_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '角色名称',
  `usernick` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '昵称',
  `username` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '用户名',
  `userpass` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '密码',
  `usersalt` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '加盐',
  `register_ip` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '注册地址',
  `register_time` datetime DEFAULT NULL COMMENT '注册时间',
  `last_ip` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '登录地址',
  `last_time` datetime DEFAULT NULL COMMENT '登录时间',
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `delete_time` datetime DEFAULT NULL,
  `state` enum('NORMAL','DISABLE') COLLATE utf8mb4_unicode_ci DEFAULT 'DISABLE' COMMENT '状态{NORMAL:正常}{DISABLE:禁用}',
  PRIMARY KEY (`id`),
  KEY `role_id` (`role_id`) USING BTREE,
  KEY `username` (`username`(191)) USING BTREE,
  KEY `delete_time` (`delete_time`) USING BTREE,
  KEY `state` (`state`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='广告主账户';

-- ----------------------------
-- Records of im_advertiser
-- ----------------------------
INSERT INTO `im_advertiser` VALUES ('1', '1', '3', '管理员', 'admin', 'admin', 'fe711720669a634139a1c650be70a4ae', 'VOKYQR', '127.0.0.1', '2022-01-01 18:00:00', '127.0.0.1', '2022-10-08 16:48:29', '2022-01-01 18:00:00', '2022-10-08 16:48:29', null, 'NORMAL');
INSERT INTO `im_advertiser` VALUES ('2', '2', '3', '管理员', 'manager', 'manager', '55cfd6ad117185fceece18cc454e7984', 'JGtlMl', '127.0.0.1', '2022-09-20 11:57:46', '127.0.0.1', '2022-09-21 17:15:56', '2022-09-20 11:57:46', '2022-09-21 17:15:56', null, 'NORMAL');
INSERT INTO `im_advertiser` VALUES ('3', '2', '3', '管理员', 'member', 'member', '77ddc03c676f3489190ed595d0bb12f6', '1KZcof', '127.0.0.1', '2022-01-01 18:00:00', '127.0.0.1', '2022-09-21 17:15:56', '2022-09-20 11:57:46', '2022-09-20 11:57:46', null, 'NORMAL');
INSERT INTO `im_advertiser` VALUES ('4', '10086', '3', '管理员', 'test1', 'test1', '77ddc03c676f3489190ed595d0bb12f6', '1KZcof', '127.0.0.1', '2022-01-01 18:00:00', '127.0.0.1', '2022-10-08 16:48:46', '2022-01-01 18:00:00', '2022-10-08 16:48:46', null, 'NORMAL');
INSERT INTO `im_advertiser` VALUES ('5', '10087', '3', '管理员', 'test2', 'test2', '77ddc03c676f3489190ed595d0bb12f6', '1KZcof', '127.0.0.1', '2022-01-01 18:00:00', '127.0.0.1', '2022-01-01 18:00:00', '2022-01-01 18:00:00', '2022-01-01 18:00:00', null, 'NORMAL');
INSERT INTO `im_advertiser` VALUES ('6', '10088', '3', '管理员', 'test3', 'test3', '0cb064d42c4605dff04c5f72ec5b56e7', 'gOBVRL', '127.0.0.1', '2022-01-01 18:00:00', '127.0.0.1', '2022-09-29 00:47:13', '2022-01-01 18:00:00', '2022-09-29 00:47:13', null, 'NORMAL');
INSERT INTO `im_advertiser` VALUES ('7', '10086', '3', '管理员', 'test22', 'test22', '4c5beb620ee5db9ab7b934a2606efa48', '20CiBZ', '127.0.0.1', '2022-09-27 00:37:39', null, null, '2022-09-27 00:37:39', '2022-09-27 18:23:48', '2022-09-27 18:23:48', 'DISABLE');

-- ----------------------------
-- Table structure for `im_channel`
-- ----------------------------
DROP TABLE IF EXISTS `im_channel`;
CREATE TABLE `im_channel` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `publishment_id` bigint(20) unsigned DEFAULT NULL,
  `site_id` bigint(20) unsigned DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL COMMENT '标题',
  `description` text COMMENT '描述',
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `delete_time` datetime DEFAULT NULL,
  `state` enum('NORMAL','DISABLE') DEFAULT 'DISABLE' COMMENT '状态{NORMAL:正常}{DISABLE:禁用}',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COMMENT='频道';

-- ----------------------------
-- Records of im_channel
-- ----------------------------
INSERT INTO `im_channel` VALUES ('1', '10086', '1', '明星详情', null, '2022-09-16 12:26:22', '2022-09-16 12:26:22', null, 'NORMAL');
INSERT INTO `im_channel` VALUES ('2', '10087', '2', '明星详情', null, '2022-09-16 12:28:05', '2022-09-16 12:28:27', null, 'NORMAL');
INSERT INTO `im_channel` VALUES ('3', '10088', '3', '明星详情', null, '2022-09-24 12:50:32', '2022-09-24 12:50:32', null, 'NORMAL');

-- ----------------------------
-- Table structure for `im_creative`
-- ----------------------------
DROP TABLE IF EXISTS `im_creative`;
CREATE TABLE `im_creative` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `advertisement_id` bigint(20) unsigned DEFAULT '0',
  `program_id` bigint(20) unsigned DEFAULT '0',
  `element_id` bigint(20) unsigned DEFAULT '0',
  `size_id` bigint(20) unsigned DEFAULT '0',
  `title` varchar(255) DEFAULT NULL COMMENT '名称',
  `location` varchar(255) DEFAULT NULL COMMENT '地址',
  `image` varchar(255) DEFAULT NULL COMMENT '物料',
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `delete_time` datetime DEFAULT NULL,
  `state` enum('NORMAL','DISABLE') DEFAULT 'DISABLE' COMMENT '状态{NORMAL:正常}{DISABLE:禁用}',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COMMENT='广告创意';

-- ----------------------------
-- Records of im_creative
-- ----------------------------
INSERT INTO `im_creative` VALUES ('1', '10086', '5', '3', '21', '980x120', 'http://v2.me.yunduanchongqing.com/?980x120', 'http://adwords.me.yunduanchongqing.com/upload/20220926/7ac5178e258dcbfe092b84c7448ad3e2.png', '2022-09-24 13:13:31', '2022-09-26 13:58:45', null, 'NORMAL');
INSERT INTO `im_creative` VALUES ('2', '10086', '5', '4', '21', '980x120-2', 'http://v2.me.yunduanchongqing.com/?980x120-2', 'http://adwords.me.yunduanchongqing.com/upload/20220926/e0cb9b1f404cae553c9247f6286c896a.png', '2022-09-24 13:14:21', '2022-09-26 13:57:37', null, 'NORMAL');
INSERT INTO `im_creative` VALUES ('3', '10086', '5', '3', '9', '300x250', 'http://v2.me.yunduanchongqing.com/?300x250', 'http://adwords.me.yunduanchongqing.com/upload/20220926/724a54c49db3d62989754539e08984e5.png', '2022-09-24 13:15:14', '2022-10-10 23:02:17', null, 'NORMAL');
INSERT INTO `im_creative` VALUES ('4', '10086', '5', '4', '9', '300x250-2', 'http://v2.me.yunduanchongqing.com/?300x250-2', 'http://adwords.me.yunduanchongqing.com/upload/20220926/addfdf3a860c593b8f763c441d73eab0.png', '2022-09-24 13:16:02', '2022-10-10 23:02:12', null, 'NORMAL');
INSERT INTO `im_creative` VALUES ('5', '10086', '5', '5', '12', '120x600', 'http://v2.me.yunduanchongqing.com/?120x600', 'http://adwords.me.yunduanchongqing.com/upload/20220926/1880d82f3e569058fcb89b13a9d11880.png', '2022-09-24 13:16:47', '2022-09-26 13:54:47', null, 'NORMAL');
INSERT INTO `im_creative` VALUES ('6', '10086', '5', '5', '21', '980x120-3', 'http://v2.me.yunduanchongqing.com/?980x120-3', 'http://adwords.me.yunduanchongqing.com/upload/20220926/6762abafab0691753bee4d018bda192d.png', '2022-09-24 14:38:26', '2022-09-26 13:52:58', null, 'NORMAL');
INSERT INTO `im_creative` VALUES ('7', '10086', '5', '4', '10', '336x280', 'http://v2.me.yunduanchongqing.com/label/about/', 'http://adwords.me.yunduanchongqing.com/upload/20220926/74a6caa680569c9caf0ca6c84fa67fbe.png', '2022-09-24 17:51:17', '2022-09-27 21:59:38', null, 'NORMAL');

-- ----------------------------
-- Table structure for `im_deposit`
-- ----------------------------
DROP TABLE IF EXISTS `im_deposit`;
CREATE TABLE `im_deposit` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `deposit_number` varchar(20) DEFAULT NULL COMMENT '交易流水号',
  `payment_number` varchar(255) DEFAULT NULL COMMENT '支付订单号',
  `deposit_id` bigint(20) unsigned DEFAULT NULL,
  `deposit_type` varchar(255) DEFAULT NULL,
  `type` enum('RECHARGE','WITHDRAW') DEFAULT 'RECHARGE' COMMENT '交易类型{充值:RECHARGE}{提现:WITHDRAW}',
  `payment` enum('ALIPAY','WECHAT','OFFLINE') DEFAULT 'OFFLINE' COMMENT '交易渠道{线下:OFFLINE}',
  `amount` bigint(20) unsigned DEFAULT NULL COMMENT '交易金额',
  `remark` varchar(255) DEFAULT NULL COMMENT '交易摘要',
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `delete_time` datetime DEFAULT NULL,
  `state` enum('SUCCESS','FAILURE','WAIT','INIT') DEFAULT 'INIT' COMMENT '状态{成功:SUCCESS}{失败:FAILURE}{待审核:WAIT}{初始化:INIT}',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='资金管理';

-- ----------------------------
-- Records of im_deposit
-- ----------------------------
INSERT INTO `im_deposit` VALUES ('1', '2022101119172769', '202210111917275453', '10086', 'advertisement', 'RECHARGE', 'OFFLINE', '10000000', '测试', '2022-10-11 19:17:27', '2022-10-11 19:17:27', null, 'SUCCESS');

-- ----------------------------
-- Table structure for `im_element`
-- ----------------------------
DROP TABLE IF EXISTS `im_element`;
CREATE TABLE `im_element` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `advertisement_id` bigint(20) unsigned DEFAULT '0',
  `program_id` bigint(20) unsigned DEFAULT '0',
  `release_begin` datetime DEFAULT NULL COMMENT '投放日期',
  `release_finish` datetime DEFAULT NULL COMMENT '投放日期',
  `period_begin` time DEFAULT NULL COMMENT '投放时段',
  `period_finish` time DEFAULT NULL COMMENT '投放时段',
  `type` enum('CPC','CPM','CPV','CPA','CPS') DEFAULT 'CPC' COMMENT '出价方式{CPC}{CPM}{CPV}{CPA}{CPS}',
  `rate` bigint(20) unsigned DEFAULT '0' COMMENT '出价',
  `title` varchar(255) DEFAULT NULL COMMENT '名称',
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `delete_time` datetime DEFAULT NULL,
  `state` enum('NORMAL','DISABLE') DEFAULT 'DISABLE' COMMENT '状态{NORMAL:正常}{DISABLE:禁用}',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COMMENT='广告单元';

-- ----------------------------
-- Records of im_element
-- ----------------------------
INSERT INTO `im_element` VALUES ('1', '1', '1', '2022-10-01 00:00:00', '2122-12-31 23:55:00', '00:00:00', '23:59:59', 'CPC', '201000', '默认推广单元', '2022-09-21 15:24:17', '2022-09-27 20:33:02', null, 'NORMAL');
INSERT INTO `im_element` VALUES ('2', '2', '3', '2022-09-15 00:00:00', '2122-12-31 23:55:00', '00:00:00', '23:59:59', 'CPC', '160000', '默认推广单元', '2022-09-21 16:10:32', '2022-09-27 20:27:09', null, 'NORMAL');
INSERT INTO `im_element` VALUES ('3', '10086', '5', '2022-09-15 00:00:00', '2122-12-31 23:55:00', '00:00:00', '23:59:59', 'CPC', '50000', 'CPC推广单元', '2022-09-24 13:08:28', '2022-10-09 11:44:10', null, 'NORMAL');
INSERT INTO `im_element` VALUES ('4', '10086', '5', '2022-09-15 00:00:00', '2122-12-31 23:55:00', '00:00:00', '23:59:59', 'CPM', '200000', 'CPM推广单元', '2022-09-24 14:37:34', '2022-09-27 20:29:22', null, 'NORMAL');
INSERT INTO `im_element` VALUES ('5', '10086', '5', '2022-09-15 00:00:00', '2122-12-31 23:55:00', '00:00:00', '23:59:59', 'CPV', '200000', 'CPV推广单元', '2022-09-24 14:37:34', '2022-09-27 20:27:53', null, 'NORMAL');
INSERT INTO `im_element` VALUES ('6', '10086', '6', '2022-09-15 00:00:00', '2122-12-31 23:55:00', '00:00:00', '23:59:59', 'CPM', '400000', 'CPM推广单元', '2022-09-24 14:37:34', '2022-10-09 11:44:04', null, 'NORMAL');

-- ----------------------------
-- Table structure for `im_industry`
-- ----------------------------
DROP TABLE IF EXISTS `im_industry`;
CREATE TABLE `im_industry` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL COMMENT '名称',
  `sorting` int(11) unsigned DEFAULT '1' COMMENT '排序',
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `delete_time` datetime DEFAULT NULL,
  `state` enum('NORMAL','DISABLE') DEFAULT 'DISABLE' COMMENT '状态{NORMAL:正常}{DISABLE:禁用}',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COMMENT='行业';

-- ----------------------------
-- Records of im_industry
-- ----------------------------
INSERT INTO `im_industry` VALUES ('1', '综合门户', '1', '2022-09-15 16:28:23', '2022-09-15 16:28:23', null, 'NORMAL');
INSERT INTO `im_industry` VALUES ('2', '生活服务', '1', '2022-09-15 16:28:33', '2022-09-15 16:28:33', null, 'NORMAL');
INSERT INTO `im_industry` VALUES ('3', '影视动漫', '1', '2022-09-15 16:28:39', '2022-09-15 16:28:39', null, 'NORMAL');
INSERT INTO `im_industry` VALUES ('4', '新闻资讯', '1', '2022-09-15 16:28:46', '2022-09-15 16:28:46', null, 'NORMAL');
INSERT INTO `im_industry` VALUES ('5', '工具服务', '1', '2022-09-15 16:28:51', '2022-09-15 16:28:51', null, 'NORMAL');
INSERT INTO `im_industry` VALUES ('6', '网络购物', '1', '2022-09-15 16:28:56', '2022-09-15 16:28:56', null, 'NORMAL');
INSERT INTO `im_industry` VALUES ('7', '社交平台', '1', '2022-09-15 16:28:57', '2022-09-15 16:29:04', null, 'NORMAL');
INSERT INTO `im_industry` VALUES ('8', '游戏', '1', '2022-09-15 16:29:25', '2022-09-15 16:29:25', null, 'NORMAL');
INSERT INTO `im_industry` VALUES ('9', '音乐', '1', '2022-09-15 16:29:34', '2022-09-15 16:29:34', null, 'NORMAL');
INSERT INTO `im_industry` VALUES ('10', '小说', '1', '2022-09-15 16:29:43', '2022-09-15 16:29:43', null, 'NORMAL');
INSERT INTO `im_industry` VALUES ('11', '医疗', '1', '2022-09-15 16:29:50', '2022-09-15 16:29:50', null, 'NORMAL');
INSERT INTO `im_industry` VALUES ('12', '金融', '1', '2022-09-15 16:30:00', '2022-09-15 16:30:00', null, 'NORMAL');
INSERT INTO `im_industry` VALUES ('13', '旅游', '1', '2022-09-15 16:30:06', '2022-09-15 16:30:06', null, 'NORMAL');
INSERT INTO `im_industry` VALUES ('14', '其它', '1', '2022-09-15 16:30:20', '2022-09-15 16:34:12', null, 'NORMAL');

-- ----------------------------
-- Table structure for `im_manager`
-- ----------------------------
DROP TABLE IF EXISTS `im_manager`;
CREATE TABLE `im_manager` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` int(11) unsigned DEFAULT '0' COMMENT '角色编号',
  `role_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '角色名称',
  `usernick` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '昵称',
  `username` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '用户名',
  `userpass` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '密码',
  `usersalt` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '加盐',
  `register_ip` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '注册地址',
  `register_time` datetime DEFAULT NULL COMMENT '注册时间',
  `last_ip` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '登录地址',
  `last_time` datetime DEFAULT NULL COMMENT '登录时间',
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `delete_time` datetime DEFAULT NULL,
  `state` enum('NORMAL','DISABLE') COLLATE utf8mb4_unicode_ci DEFAULT 'DISABLE' COMMENT '状态{NORMAL:正常}{DISABLE:禁用}',
  PRIMARY KEY (`id`),
  KEY `role_id` (`role_id`) USING BTREE,
  KEY `username` (`username`(191)) USING BTREE,
  KEY `delete_time` (`delete_time`) USING BTREE,
  KEY `state` (`state`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='后台账户';

-- ----------------------------
-- Records of im_manager
-- ----------------------------
INSERT INTO `im_manager` VALUES ('1', '1', '超级管理组', '创始人', 'founder', '0957ca902212979ffd4c4927f0b45def', 'Y181VY', '127.0.0.1', '2022-01-01 18:00:00', '127.0.0.1', '2022-10-09 00:30:43', '2022-01-01 18:00:00', '2022-10-09 00:30:43', null, 'NORMAL');
INSERT INTO `im_manager` VALUES ('2', '2', '管理员', '管理员', 'admin', 'fe711720669a634139a1c650be70a4ae', 'VOKYQR', '127.0.0.1', '2022-01-01 18:00:00', '127.0.0.1', '2022-08-23 23:24:18', '2022-01-01 18:00:00', '2022-08-23 23:24:18', null, 'NORMAL');

-- ----------------------------
-- Table structure for `im_material`
-- ----------------------------
DROP TABLE IF EXISTS `im_material`;
CREATE TABLE `im_material` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `publishment_id` bigint(20) unsigned DEFAULT '0',
  `size_id` bigint(20) unsigned DEFAULT '0',
  `title` varchar(255) DEFAULT NULL COMMENT '名称',
  `device` enum('PC','MOBILE') DEFAULT 'PC' COMMENT '设备{PC:电脑}{MOBILE:移动端}',
  `location` varchar(255) DEFAULT NULL COMMENT '地址',
  `image` varchar(255) DEFAULT NULL COMMENT '物料',
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `delete_time` datetime DEFAULT NULL,
  `state` enum('NORMAL','DISABLE') DEFAULT 'DISABLE' COMMENT '状态{NORMAL:正常}{DISABLE:禁用}',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COMMENT='广告物料';

-- ----------------------------
-- Records of im_material
-- ----------------------------
INSERT INTO `im_material` VALUES ('1', '1', '5', '200x200-g', 'PC', 'http://v2.me.yunduanchongqing.com/?200x200-g', 'http://adwords.me.yunduanchongqing.com/upload/20220925/819dc5ba5c23d7aa13c0a103d3ba522f.png', '2022-09-26 12:02:28', '2022-09-26 12:02:28', null, 'NORMAL');
INSERT INTO `im_material` VALUES ('2', '1', '6', '240x400-g', 'PC', 'http://v2.me.yunduanchongqing.com/?240x400-g', 'http://adwords.me.yunduanchongqing.com/upload/20220925/da0fcef00186d64953cfe73e116b79fd.png', '2022-09-26 12:02:28', '2022-09-26 12:02:28', null, 'NORMAL');
INSERT INTO `im_material` VALUES ('3', '1', '7', '250x250-g', 'PC', 'http://v2.me.yunduanchongqing.com/?250x250-g', 'http://adwords.me.yunduanchongqing.com/upload/20220925/b437c409a495ee543fb5b5a7d89cb4ec.png', '2022-09-26 12:02:28', '2022-09-26 12:02:28', null, 'NORMAL');
INSERT INTO `im_material` VALUES ('4', '1', '8', '250x360-g', 'PC', 'http://v2.me.yunduanchongqing.com/?250x360-g', 'http://adwords.me.yunduanchongqing.com/upload/20220925/7bd78394da3599b8d383215d3a5cf20d.png', '2022-09-26 12:02:28', '2022-09-26 12:02:28', null, 'NORMAL');
INSERT INTO `im_material` VALUES ('5', '1', '9', '300x250-g', 'PC', 'http://v2.me.yunduanchongqing.com/?300x250-g', 'http://adwords.me.yunduanchongqing.com/upload/20220925/5d2a62a4f311108b16e486375788d04a.png', '2022-09-26 12:02:28', '2022-09-26 12:02:28', null, 'NORMAL');
INSERT INTO `im_material` VALUES ('6', '1', '10', '336x280-g', 'PC', 'http://v2.me.yunduanchongqing.com/?336x280-g', 'http://adwords.me.yunduanchongqing.com/upload/20220925/7e6cd33342968c56284e59417be26caf.png', '2022-09-26 12:02:28', '2022-09-26 12:02:28', null, 'NORMAL');
INSERT INTO `im_material` VALUES ('7', '1', '11', '580x400-g', 'PC', 'http://v2.me.yunduanchongqing.com/?580x400-g', 'http://adwords.me.yunduanchongqing.com/upload/20220925/aee2d6bcb1855b839ad82f1c23802fb3.png', '2022-09-26 12:02:28', '2022-09-26 12:02:28', null, 'NORMAL');
INSERT INTO `im_material` VALUES ('8', '1', '12', '120x600-g', 'PC', 'http://v2.me.yunduanchongqing.com/?120x600-g', 'http://adwords.me.yunduanchongqing.com/upload/20220925/78405de9be022c33255c0389a2da1cef.png', '2022-09-26 12:02:28', '2022-09-26 22:42:05', null, 'NORMAL');
INSERT INTO `im_material` VALUES ('9', '1', '13', '160x600-g', 'PC', 'http://v2.me.yunduanchongqing.com/?160x600-g', 'http://adwords.me.yunduanchongqing.com/upload/20220925/cd890914dc0b7e2890a95ffd58911ca7.png', '2022-09-26 12:02:28', '2022-09-26 22:42:08', null, 'NORMAL');
INSERT INTO `im_material` VALUES ('10', '1', '14', '300x600-g', 'PC', 'http://v2.me.yunduanchongqing.com/?300x600-g', 'http://adwords.me.yunduanchongqing.com/upload/20220925/c0c2a17bf9dbae6c0fabfc85db3b156f.png', '2022-09-26 12:02:28', '2022-09-26 12:02:28', null, 'NORMAL');
INSERT INTO `im_material` VALUES ('11', '1', '15', '300x1050-g', 'PC', 'http://v2.me.yunduanchongqing.com/?300x1050-g', 'http://adwords.me.yunduanchongqing.com/upload/20220925/a6d4e28908d4b8099302ff260ece2593.png', '2022-09-26 12:02:28', '2022-09-26 12:02:28', null, 'NORMAL');
INSERT INTO `im_material` VALUES ('12', '1', '16', '486x60-g', 'PC', 'http://v2.me.yunduanchongqing.com/?486x60-g', 'http://adwords.me.yunduanchongqing.com/upload/20220925/bdbbeec09fddbf467988aac8ba6abadc.png', '2022-09-26 12:02:28', '2022-09-26 12:02:28', null, 'NORMAL');
INSERT INTO `im_material` VALUES ('13', '1', '17', '728x90-g', 'PC', 'http://v2.me.yunduanchongqing.com/?728x90-g', 'http://adwords.me.yunduanchongqing.com/upload/20220925/a7ea821541eb7f572f804bddf98636a9.png', '2022-09-26 12:02:28', '2022-09-26 12:02:28', null, 'NORMAL');
INSERT INTO `im_material` VALUES ('14', '1', '18', '930x180-g', 'PC', 'http://v2.me.yunduanchongqing.com/?930x180-g', 'http://adwords.me.yunduanchongqing.com/upload/20220925/2f5e8c0ab0f22535ce8f4c4db3c94fb1.png', '2022-09-26 12:02:28', '2022-09-26 12:02:28', null, 'NORMAL');
INSERT INTO `im_material` VALUES ('15', '1', '19', '970x90-g', 'PC', 'http://v2.me.yunduanchongqing.com/?970x90-g', 'http://adwords.me.yunduanchongqing.com/upload/20220925/92c67dcc62abe42152257dc1fd60f375.png', '2022-09-26 12:02:28', '2022-09-26 12:02:28', null, 'NORMAL');
INSERT INTO `im_material` VALUES ('16', '1', '20', '970x250-g', 'PC', 'http://v2.me.yunduanchongqing.com/?970x250-g', 'http://adwords.me.yunduanchongqing.com/upload/20220925/052d34c36ab784e32033cf99c6046bc5.png', '2022-09-26 12:02:28', '2022-09-26 12:02:28', null, 'NORMAL');
INSERT INTO `im_material` VALUES ('17', '1', '21', '980x120-g', 'PC', 'http://v2.me.yunduanchongqing.com/?980x120-g', 'http://adwords.me.yunduanchongqing.com/upload/20220925/b1023b4548c90fdc01b480a21eaf2aa2.png', '2022-09-26 12:02:28', '2022-09-26 12:02:28', null, 'NORMAL');
INSERT INTO `im_material` VALUES ('18', '1', '22', '300x50-g', 'PC', 'http://v2.me.yunduanchongqing.com/?300x50-g', 'http://adwords.me.yunduanchongqing.com/upload/20220925/b4a584b7793f8a1f3e8ab6fa20481233.png', '2022-09-26 12:02:28', '2022-09-26 12:02:28', null, 'NORMAL');
INSERT INTO `im_material` VALUES ('19', '1', '23', '320x50-g', 'PC', 'http://v2.me.yunduanchongqing.com/?320x50-g', 'http://adwords.me.yunduanchongqing.com/upload/20220925/cec241c436250b4c62e52e5a65cad755.png', '2022-09-26 12:02:28', '2022-09-26 12:02:28', null, 'NORMAL');
INSERT INTO `im_material` VALUES ('20', '1', '24', '320x100-g', 'PC', 'http://v2.me.yunduanchongqing.com/?320x100-g', 'http://adwords.me.yunduanchongqing.com/upload/20220925/00d1e8293eb9d979e7066cb60625396f.png', '2022-09-26 12:02:28', '2022-09-26 12:02:28', null, 'NORMAL');
INSERT INTO `im_material` VALUES ('21', '1', '9', '300x250-g', 'MOBILE', 'http://v2.me.yunduanchongqing.com/?300x250-g', 'http://adwords.me.yunduanchongqing.com/upload/20220925/5d2a62a4f311108b16e486375788d04a.png', '2022-09-26 12:02:28', '2022-09-26 12:02:28', null, 'NORMAL');
INSERT INTO `im_material` VALUES ('22', '1', '22', '300x50-g', 'MOBILE', 'http://v2.me.yunduanchongqing.com/?300x50-g', 'http://adwords.me.yunduanchongqing.com/upload/20220925/b4a584b7793f8a1f3e8ab6fa20481233.png', '2022-09-26 12:02:28', '2022-09-26 12:02:28', null, 'NORMAL');
INSERT INTO `im_material` VALUES ('23', '1', '23', '320x50-g', 'MOBILE', 'http://v2.me.yunduanchongqing.com/?320x50-g', 'http://adwords.me.yunduanchongqing.com/upload/20220925/cec241c436250b4c62e52e5a65cad755.png', '2022-09-26 12:02:28', '2022-09-26 12:02:28', null, 'NORMAL');
INSERT INTO `im_material` VALUES ('24', '1', '24', '320x100-g', 'MOBILE', 'http://v2.me.yunduanchongqing.com/?320x100-g', 'http://adwords.me.yunduanchongqing.com/upload/20220925/00d1e8293eb9d979e7066cb60625396f.png', '2022-09-26 12:02:28', '2022-09-26 12:02:28', null, 'NORMAL');
INSERT INTO `im_material` VALUES ('25', '2', '5', '200x200-h', 'PC', 'http://v2.me.yunduanchongqing.com/?200x200-h', 'http://adwords.me.yunduanchongqing.com/upload/20220926/819dc5ba5c23d7aa13c0a103d3ba522f.png', '2022-09-26 12:02:28', '2022-09-26 12:02:28', null, 'NORMAL');
INSERT INTO `im_material` VALUES ('26', '2', '6', '240x400-h', 'PC', 'http://v2.me.yunduanchongqing.com/?240x400-h', 'http://adwords.me.yunduanchongqing.com/upload/20220926/da0fcef00186d64953cfe73e116b79fd.png', '2022-09-26 12:02:28', '2022-09-26 12:02:28', null, 'NORMAL');
INSERT INTO `im_material` VALUES ('27', '2', '7', '250x250-h', 'PC', 'http://v2.me.yunduanchongqing.com/?250x250-h', 'http://adwords.me.yunduanchongqing.com/upload/20220926/b437c409a495ee543fb5b5a7d89cb4ec.png', '2022-09-26 12:02:28', '2022-09-26 12:02:28', null, 'NORMAL');
INSERT INTO `im_material` VALUES ('28', '2', '8', '250x360-h', 'PC', 'http://v2.me.yunduanchongqing.com/?250x360-h', 'http://adwords.me.yunduanchongqing.com/upload/20220926/7bd78394da3599b8d383215d3a5cf20d.png', '2022-09-26 12:02:28', '2022-09-26 12:02:28', null, 'NORMAL');
INSERT INTO `im_material` VALUES ('29', '2', '9', '300x250-h', 'PC', 'http://v2.me.yunduanchongqing.com/?300x250-h', 'http://adwords.me.yunduanchongqing.com/upload/20220926/5d2a62a4f311108b16e486375788d04a.png', '2022-09-26 12:02:28', '2022-09-26 12:02:28', null, 'NORMAL');
INSERT INTO `im_material` VALUES ('30', '2', '10', '336x280-h', 'PC', 'http://v2.me.yunduanchongqing.com/?336x280-h', 'http://adwords.me.yunduanchongqing.com/upload/20220926/7e6cd33342968c56284e59417be26caf.png', '2022-09-26 12:02:28', '2022-09-26 12:02:28', null, 'NORMAL');
INSERT INTO `im_material` VALUES ('31', '2', '11', '580x400-h', 'PC', 'http://v2.me.yunduanchongqing.com/?580x400-h', 'http://adwords.me.yunduanchongqing.com/upload/20220926/aee2d6bcb1855b839ad82f1c23802fb3.png', '2022-09-26 12:02:28', '2022-09-26 12:02:28', null, 'NORMAL');
INSERT INTO `im_material` VALUES ('32', '2', '12', '120x600-h', 'PC', 'http://v2.me.yunduanchongqing.com/?120x600-h', 'http://adwords.me.yunduanchongqing.com/upload/20220926/78405de9be022c33255c0389a2da1cef.png', '2022-09-26 12:02:28', '2022-09-26 12:02:28', null, 'NORMAL');
INSERT INTO `im_material` VALUES ('33', '2', '13', '160x600-h', 'PC', 'http://v2.me.yunduanchongqing.com/?160x600-h', 'http://adwords.me.yunduanchongqing.com/upload/20220926/cd890914dc0b7e2890a95ffd58911ca7.png', '2022-09-26 12:02:28', '2022-09-26 12:02:28', null, 'NORMAL');
INSERT INTO `im_material` VALUES ('34', '2', '14', '300x600-h', 'PC', 'http://v2.me.yunduanchongqing.com/?300x600-h', 'http://adwords.me.yunduanchongqing.com/upload/20220926/c0c2a17bf9dbae6c0fabfc85db3b156f.png', '2022-09-26 12:02:28', '2022-09-26 12:02:28', null, 'NORMAL');
INSERT INTO `im_material` VALUES ('35', '2', '15', '300x1050-h', 'PC', 'http://v2.me.yunduanchongqing.com/?300x1050-h', 'http://adwords.me.yunduanchongqing.com/upload/20220926/a6d4e28908d4b8099302ff260ece2593.png', '2022-09-26 12:02:28', '2022-09-26 12:02:28', null, 'NORMAL');
INSERT INTO `im_material` VALUES ('36', '2', '16', '486x60-h', 'PC', 'http://v2.me.yunduanchongqing.com/?486x60-h', 'http://adwords.me.yunduanchongqing.com/upload/20220926/bdbbeec09fddbf467988aac8ba6abadc.png', '2022-09-26 12:02:28', '2022-09-26 12:02:28', null, 'NORMAL');
INSERT INTO `im_material` VALUES ('37', '2', '17', '728x90-h', 'PC', 'http://v2.me.yunduanchongqing.com/?728x90-h', 'http://adwords.me.yunduanchongqing.com/upload/20220926/a7ea821541eb7f572f804bddf98636a9.png', '2022-09-26 12:02:28', '2022-09-26 12:02:28', null, 'NORMAL');
INSERT INTO `im_material` VALUES ('38', '2', '18', '930x180-h', 'PC', 'http://v2.me.yunduanchongqing.com/?930x180-h', 'http://adwords.me.yunduanchongqing.com/upload/20220926/2f5e8c0ab0f22535ce8f4c4db3c94fb1.png', '2022-09-26 12:02:28', '2022-09-26 12:02:28', null, 'NORMAL');
INSERT INTO `im_material` VALUES ('39', '2', '19', '970x90-h', 'PC', 'http://v2.me.yunduanchongqing.com/?970x90-h', 'http://adwords.me.yunduanchongqing.com/upload/20220926/92c67dcc62abe42152257dc1fd60f375.png', '2022-09-26 12:02:28', '2022-09-26 12:02:28', null, 'NORMAL');
INSERT INTO `im_material` VALUES ('40', '2', '20', '970x250-h', 'PC', 'http://v2.me.yunduanchongqing.com/?970x250-h', 'http://adwords.me.yunduanchongqing.com/upload/20220926/052d34c36ab784e32033cf99c6046bc5.png', '2022-09-26 12:02:28', '2022-09-26 12:02:28', null, 'NORMAL');
INSERT INTO `im_material` VALUES ('41', '2', '21', '980x120-h', 'PC', 'http://v2.me.yunduanchongqing.com/?980x120-h', 'http://adwords.me.yunduanchongqing.com/upload/20220926/b1023b4548c90fdc01b480a21eaf2aa2.png', '2022-09-26 12:02:28', '2022-09-26 12:02:28', null, 'NORMAL');
INSERT INTO `im_material` VALUES ('42', '2', '22', '300x50-h', 'PC', 'http://v2.me.yunduanchongqing.com/?300x50-h', 'http://adwords.me.yunduanchongqing.com/upload/20220926/b4a584b7793f8a1f3e8ab6fa20481233.png', '2022-09-26 12:02:28', '2022-09-26 12:02:28', null, 'NORMAL');
INSERT INTO `im_material` VALUES ('43', '2', '23', '320x50-h', 'PC', 'http://v2.me.yunduanchongqing.com/?320x50-h', 'http://adwords.me.yunduanchongqing.com/upload/20220926/cec241c436250b4c62e52e5a65cad755.png', '2022-09-26 12:02:28', '2022-09-26 12:02:28', null, 'NORMAL');
INSERT INTO `im_material` VALUES ('44', '2', '24', '320x100-h', 'PC', 'http://v2.me.yunduanchongqing.com/?320x100-h', 'http://adwords.me.yunduanchongqing.com/upload/20220926/00d1e8293eb9d979e7066cb60625396f.png', '2022-09-26 12:02:28', '2022-09-26 12:02:28', null, 'NORMAL');
INSERT INTO `im_material` VALUES ('45', '2', '9', '300x250-h', 'MOBILE', 'http://v2.me.yunduanchongqing.com/?300x250-h', 'http://adwords.me.yunduanchongqing.com/upload/20220926/5d2a62a4f311108b16e486375788d04a.png', '2022-09-26 12:02:28', '2022-09-26 12:02:28', null, 'NORMAL');
INSERT INTO `im_material` VALUES ('46', '2', '22', '300x50-h', 'MOBILE', 'http://v2.me.yunduanchongqing.com/?300x50-h', 'http://adwords.me.yunduanchongqing.com/upload/20220926/b4a584b7793f8a1f3e8ab6fa20481233.png', '2022-09-26 12:02:28', '2022-09-26 12:02:28', null, 'NORMAL');
INSERT INTO `im_material` VALUES ('47', '2', '23', '320x50-h', 'MOBILE', 'http://v2.me.yunduanchongqing.com/?320x50-h', 'http://adwords.me.yunduanchongqing.com/upload/20220926/cec241c436250b4c62e52e5a65cad755.png', '2022-09-26 12:02:28', '2022-09-26 12:02:28', null, 'NORMAL');
INSERT INTO `im_material` VALUES ('48', '2', '24', '320x100-h', 'MOBILE', 'http://v2.me.yunduanchongqing.com/?320x100-h', 'http://adwords.me.yunduanchongqing.com/upload/20220926/00d1e8293eb9d979e7066cb60625396f.png', '2022-09-26 12:02:28', '2022-09-26 12:02:28', null, 'NORMAL');

-- ----------------------------
-- Table structure for `im_module`
-- ----------------------------
DROP TABLE IF EXISTS `im_module`;
CREATE TABLE `im_module` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `namespace` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '标识符',
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '模块名称',
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '描述',
  `sorting` int(11) unsigned DEFAULT '1' COMMENT '排序',
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `delete_time` datetime DEFAULT NULL,
  `state` enum('NORMAL','DISABLE') COLLATE utf8mb4_unicode_ci DEFAULT 'DISABLE' COMMENT '状态{NORMAL:正常}{DISABLE:禁用}',
  PRIMARY KEY (`id`),
  KEY `namespace` (`namespace`(191),`state`) USING BTREE,
  KEY `sorting` (`sorting`,`state`) USING BTREE,
  KEY `delete_time` (`delete_time`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='模块';

-- ----------------------------
-- Records of im_module
-- ----------------------------
INSERT INTO `im_module` VALUES ('1', 'BACKEND', '后台模块', null, '1', '2022-08-23 16:32:56', '2022-08-23 16:32:56', null, 'NORMAL');
INSERT INTO `im_module` VALUES ('2', 'ADVERTISEMENT', '广告主平台', null, '1', '2022-09-15 17:51:46', '2022-09-15 17:51:46', null, 'NORMAL');
INSERT INTO `im_module` VALUES ('3', 'PUBLISHMENT', '流量主平台', null, '1', '2022-09-15 17:52:05', '2022-09-15 17:52:05', null, 'NORMAL');

-- ----------------------------
-- Table structure for `im_policy`
-- ----------------------------
DROP TABLE IF EXISTS `im_policy`;
CREATE TABLE `im_policy` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `module_namespace` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '标识符',
  `module_id` int(11) unsigned DEFAULT '0' COMMENT '所属模块',
  `pid` int(11) unsigned DEFAULT '0' COMMENT '父级编号',
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '名称',
  `type` enum('NAVIGATION','PAGE','NODE') COLLATE utf8mb4_unicode_ci DEFAULT 'NODE' COMMENT '菜单{NAVIGATION:菜单}{PAGE:页面}{NODE:节点}',
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '图标',
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '地址',
  `statement` text COLLATE utf8mb4_unicode_ci COMMENT '授权语句',
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '描述',
  `sorting` int(11) unsigned DEFAULT '1' COMMENT '排序',
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `delete_time` datetime DEFAULT NULL,
  `state` enum('NORMAL','DISABLE') COLLATE utf8mb4_unicode_ci DEFAULT 'DISABLE' COMMENT '状态{NORMAL:正常}{DISABLE:禁用}',
  PRIMARY KEY (`id`),
  KEY `module_namespace` (`module_namespace`(191),`state`) USING BTREE,
  KEY `module_id` (`module_id`,`state`) USING BTREE,
  KEY `pid` (`pid`,`state`) USING BTREE,
  KEY `navigation` (`type`,`state`) USING BTREE,
  KEY `sorting` (`sorting`,`state`) USING BTREE,
  KEY `delete_time` (`delete_time`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=235 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='策略';

-- ----------------------------
-- Records of im_policy
-- ----------------------------
INSERT INTO `im_policy` VALUES ('1', 'BACKEND', '1', '0', '系统管理', 'NAVIGATION', 'icon-settings', null, null, null, '1', '2022-08-23 17:27:26', '2022-08-23 18:01:11', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('2', 'BACKEND', '1', '0', '模块管理', 'NAVIGATION', 'icon-layers', null, null, null, '1', '2022-08-23 17:27:35', '2022-08-23 17:27:35', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('3', 'BACKEND', '1', '0', '策略管理', 'NAVIGATION', 'icon-badge', null, null, null, '1', '2022-08-23 17:27:54', '2022-08-23 17:27:54', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('4', 'BACKEND', '1', '0', '角色管理', 'NAVIGATION', 'icon-grid', null, null, null, '1', '2022-08-23 17:27:46', '2022-08-23 17:27:46', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('5', 'BACKEND', '1', '0', '账户管理', 'NAVIGATION', 'icon-people', null, null, null, '1', '2022-08-23 17:28:02', '2022-08-23 17:28:02', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('110', 'BACKEND', '1', '2', '模块管理', 'PAGE', 'icon-settings', 'backend.module.list', 'backend.module.list', null, '1', '2022-08-23 17:29:09', '2022-08-23 17:29:09', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('111', 'BACKEND', '1', '110', '新增模块', 'NODE', 'icon-settings', 'backend.module.create', 'backend.module.create,backend.module.store', null, '1', '2022-08-23 17:29:56', '2022-08-23 17:29:56', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('112', 'BACKEND', '1', '110', '编辑模块', 'NODE', 'icon-settings', 'backend.module.edit', 'backend.module.edit,backend.module.update', null, '1', '2022-08-23 17:30:14', '2022-08-23 17:30:14', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('113', 'BACKEND', '1', '110', '删除模块', 'NODE', 'icon-settings', 'backend.module.destroy', 'backend.module.destroy', null, '1', '2022-08-23 17:31:09', '2022-08-23 17:31:09', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('114', 'BACKEND', '1', '3', '策略管理', 'PAGE', 'icon-settings', 'backend.policy.list', 'backend.policy.list', null, '1', '2022-08-23 17:32:38', '2022-08-23 17:32:38', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('115', 'BACKEND', '1', '114', '新增策略', 'NODE', 'icon-settings', 'backend.policy.create', 'backend.policy.create,backend.policy.store', null, '1', '2022-08-23 17:33:01', '2022-08-23 17:33:01', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('116', 'BACKEND', '1', '114', '编辑策略', 'NODE', 'icon-settings', 'backend.policy.edit', 'backend.policy.edit,backend.policy.update', null, '1', '2022-08-23 17:33:18', '2022-08-23 17:33:18', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('117', 'BACKEND', '1', '114', '删除策略', 'NODE', 'icon-settings', 'backend.policy.destroy', 'backend.policy.destroy', null, '1', '2022-08-23 17:33:31', '2022-08-23 17:33:31', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('118', 'BACKEND', '1', '4', '角色管理', 'PAGE', 'icon-settings', 'backend.role.list', 'backend.role.list', null, '1', '2022-08-23 17:34:56', '2022-08-23 17:34:56', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('119', 'BACKEND', '1', '118', '新增角色', 'NODE', 'icon-settings', 'backend.role.create', 'backend.role.create,backend.role.store', null, '1', '2022-08-23 17:35:18', '2022-08-23 17:35:18', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('120', 'BACKEND', '1', '118', '编辑角色', 'NODE', 'icon-settings', 'backend.role.edit', 'backend.role.edit,backend.role.update', null, '1', '2022-08-23 17:35:36', '2022-08-23 17:35:36', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('121', 'BACKEND', '1', '118', '删除角色', 'NODE', 'icon-settings', 'backend.role.destroy', 'backend.role.destroy', null, '1', '2022-08-23 17:35:51', '2022-08-23 17:35:51', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('122', 'BACKEND', '1', '5', '账户管理', 'PAGE', 'icon-settings', 'backend.manager.list', 'backend.manager.list', null, '1', '2022-08-23 17:36:20', '2022-08-23 17:36:20', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('123', 'BACKEND', '1', '122', '新增账户', 'NODE', 'icon-settings', 'backend.manager.create', 'backend.manager.create,backend.manager.store', null, '1', '2022-08-23 17:36:35', '2022-08-23 17:36:35', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('124', 'BACKEND', '1', '122', '编辑账户', 'NODE', 'icon-settings', 'backend.manager.edit', 'backend.manager.edit,backend.manager.update', null, '1', '2022-08-23 17:36:52', '2022-08-23 17:36:52', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('125', 'BACKEND', '1', '122', '删除账户', 'NODE', 'icon-settings', 'backend.manager.destroy', 'backend.manager.destroy', null, '1', '2022-08-23 17:37:09', '2022-08-23 17:37:09', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('126', 'BACKEND', '1', '122', '重置密码', 'NODE', 'icon-settings', 'backend.manager.password', 'backend.manager.password', null, '1', '2022-08-23 18:19:58', '2022-09-27 00:05:55', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('127', 'BACKEND', '1', '0', '行业管理', 'NAVIGATION', 'icon-settings', null, '', null, '1', '2022-09-15 13:55:48', '2022-09-15 13:55:48', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('128', 'BACKEND', '1', '127', '行业管理', 'PAGE', 'icon-settings', 'backend.industry.list', 'backend.industry.list', null, '1', '2022-09-15 13:56:09', '2022-09-15 13:56:09', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('129', 'BACKEND', '1', '128', '新增行业', 'NODE', 'icon-settings', 'backend.industry.create', 'backend.industry.create,backend.industry.store', null, '1', '2022-09-15 13:56:27', '2022-09-15 13:56:27', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('130', 'BACKEND', '1', '128', '编辑行业', 'NODE', 'icon-settings', 'backend.industry.edit', 'backend.industry.edit,backend.industry.update', null, '1', '2022-09-15 13:56:44', '2022-09-15 13:56:44', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('131', 'BACKEND', '1', '128', '删除行业', 'NODE', 'icon-settings', 'backend.industry.destroy', 'backend.industry.destroy', null, '1', '2022-09-15 13:57:01', '2022-09-15 13:57:01', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('132', 'PUBLISHMENT', '3', '0', '站点管理', 'NAVIGATION', 'icon-settings', null, '', null, '1', '2022-09-15 20:37:35', '2022-09-15 20:37:35', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('133', 'PUBLISHMENT', '3', '132', '站点管理', 'PAGE', 'icon-settings', 'publishment.site.list', 'publishment.site.list', null, '1', '2022-09-15 20:38:03', '2022-09-15 20:38:25', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('134', 'PUBLISHMENT', '3', '133', '新增站点', 'NODE', 'icon-settings', 'publishment.site.create', 'publishment.site.create,publishment.site.store,publishment.site.verify,publishment.site.verification,publishment.site.download', null, '1', '2022-09-15 20:38:44', '2022-09-15 22:52:24', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('135', 'PUBLISHMENT', '3', '133', '编辑站点', 'NODE', 'icon-settings', 'publishment.site.edit', 'publishment.site.edit,publishment.site.update', null, '1', '2022-09-15 20:38:59', '2022-09-15 20:38:59', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('136', 'PUBLISHMENT', '3', '133', '删除站点', 'NODE', 'icon-settings', 'publishment.site.destroy', 'publishment.site.destroy', null, '1', '2022-09-15 20:39:14', '2022-09-15 20:39:14', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('137', 'PUBLISHMENT', '3', '132', '频道管理', 'PAGE', 'icon-settings', 'publishment.channel.list', 'publishment.channel.list', null, '1', '2022-09-16 12:08:38', '2022-09-16 12:08:38', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('138', 'PUBLISHMENT', '3', '137', '新增频道', 'NODE', 'icon-settings', 'publishment.channel.create', 'publishment.channel.create,publishment.channel.store', null, '1', '2022-09-16 12:08:57', '2022-09-16 12:08:57', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('139', 'PUBLISHMENT', '3', '137', '编辑频道', 'NODE', 'icon-settings', 'publishment.channel.edit', 'publishment.channel.edit,publishment.channel.update', null, '1', '2022-09-16 12:09:15', '2022-09-16 12:09:15', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('140', 'PUBLISHMENT', '3', '137', '删除频道', 'NODE', 'icon-settings', 'publishment.channel.destroy', 'publishment.channel.destroy', null, '1', '2022-09-16 12:09:30', '2022-09-16 12:09:30', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('141', 'BACKEND', '1', '127', '广告尺寸', 'PAGE', 'icon-settings', 'backend.size.list', 'backend.size.list', null, '1', '2022-09-17 14:40:24', '2022-09-17 14:40:24', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('142', 'BACKEND', '1', '141', '新增广告尺寸', 'NODE', 'icon-settings', 'backend.size.create', 'backend.size.create,backend.size.store', null, '1', '2022-09-17 14:40:43', '2022-09-17 14:40:43', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('143', 'BACKEND', '1', '141', '编辑广告尺寸', 'NODE', 'icon-settings', 'backend.size.edit', 'backend.size.edit,backend.size.update', null, '1', '2022-09-17 14:40:58', '2022-09-17 14:40:58', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('144', 'BACKEND', '1', '141', '删除广告尺寸', 'NODE', 'icon-settings', 'backend.size.destroy', 'backend.size.destroy', null, '1', '2022-09-17 14:41:14', '2022-09-17 14:41:14', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('145', 'PUBLISHMENT', '3', '0', '广告位管理', 'NAVIGATION', 'icon-settings', null, '', null, '1', '2022-09-18 22:35:36', '2022-09-18 22:35:36', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('146', 'PUBLISHMENT', '3', '145', '广告位管理', 'PAGE', 'icon-settings', 'publishment.adsense.list', 'publishment.adsense.list,publishment.adsense.code', null, '1', '2022-09-18 22:36:04', '2022-09-26 18:11:44', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('147', 'PUBLISHMENT', '3', '146', '新增广告位', 'NODE', 'icon-settings', 'publishment.adsense.create', 'publishment.adsense.create,publishment.adsense.store', null, '1', '2022-09-18 22:36:20', '2022-09-18 22:36:20', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('148', 'PUBLISHMENT', '3', '146', '编辑广告位', 'NODE', 'icon-settings', 'publishment.adsense.edit', 'publishment.adsense.edit,publishment.adsense.update', null, '1', '2022-09-18 22:36:36', '2022-09-18 22:36:36', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('149', 'PUBLISHMENT', '3', '146', '删除广告位', 'NODE', 'icon-settings', 'publishment.adsense.destroy', 'publishment.adsense.destroy', null, '1', '2022-09-18 22:36:50', '2022-09-18 22:36:50', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('150', 'ADVERTISEMENT', '2', '0', '推广', 'NAVIGATION', 'icon-settings', null, '', null, '1', '2022-09-20 16:20:48', '2022-09-20 16:20:48', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('151', 'ADVERTISEMENT', '2', '150', '广告计划', 'PAGE', 'icon-settings', 'advertisement.program.list', 'advertisement.program.list', null, '1', '2022-09-20 16:22:11', '2022-09-20 16:22:11', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('152', 'ADVERTISEMENT', '2', '151', '新建广告计划', 'NODE', 'icon-settings', 'advertisement.program.create', 'advertisement.program.create,advertisement.program.store', null, '1', '2022-09-20 16:22:30', '2022-09-20 16:22:30', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('153', 'ADVERTISEMENT', '2', '151', '编辑广告计划', 'NODE', 'icon-settings', 'advertisement.program.edit', 'advertisement.program.edit,advertisement.program.update', null, '1', '2022-09-20 16:22:51', '2022-09-20 16:22:51', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('154', 'ADVERTISEMENT', '2', '151', '删除广告计划', 'NODE', 'icon-settings', 'advertisement.program.destroy', 'advertisement.program.destroy', null, '1', '2022-09-20 16:23:10', '2022-09-20 16:23:10', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('155', 'ADVERTISEMENT', '2', '150', '广告单元', 'PAGE', 'icon-settings', 'advertisement.element.list', 'advertisement.element.list', null, '1', '2022-09-20 16:23:30', '2022-09-20 16:23:30', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('156', 'ADVERTISEMENT', '2', '155', '新增广告单元', 'NODE', 'icon-settings', 'advertisement.element.create', 'advertisement.element.create,advertisement.element.store', null, '1', '2022-09-20 16:23:51', '2022-09-20 16:23:51', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('157', 'ADVERTISEMENT', '2', '155', '编辑广告单元', 'NODE', 'icon-settings', 'advertisement.element.edit', 'advertisement.element.edit,advertisement.element.update', null, '1', '2022-09-20 16:24:15', '2022-09-20 16:24:15', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('158', 'ADVERTISEMENT', '2', '155', '删除广告单元', 'NODE', 'icon-settings', 'advertisement.element.destroy', 'advertisement.element.destroy', null, '1', '2022-09-20 16:24:33', '2022-09-20 16:24:33', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('159', 'ADVERTISEMENT', '2', '150', '广告创意', 'PAGE', 'icon-settings', 'advertisement.creative.list', 'advertisement.creative.list', null, '1', '2022-09-20 16:25:16', '2022-09-20 16:25:16', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('160', 'ADVERTISEMENT', '2', '159', '新增广告创意', 'NODE', 'icon-settings', 'advertisement.creative.create', 'advertisement.creative.create,advertisement.creative.store', null, '1', '2022-09-20 16:25:34', '2022-09-20 16:25:34', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('161', 'ADVERTISEMENT', '2', '159', '编辑广告创意', 'NODE', 'icon-settings', 'advertisement.creative.edit', 'advertisement.creative.edit,advertisement.creative.update', null, '1', '2022-09-20 16:25:50', '2022-09-20 16:25:50', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('162', 'ADVERTISEMENT', '2', '159', '删除广告创意', 'NODE', 'icon-settings', 'advertisement.creative.destroy', 'advertisement.creative.destroy', null, '1', '2022-09-20 16:26:06', '2022-09-20 16:26:06', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('163', 'PUBLISHMENT', '3', '0', '换量广告', 'NAVIGATION', 'icon-settings', null, '', null, '1', '2022-09-25 14:55:05', '2022-09-25 14:55:05', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('164', 'PUBLISHMENT', '3', '163', '广告物料', 'PAGE', 'icon-settings', 'publishment.material.list', 'publishment.material.list', null, '1', '2022-09-25 14:55:27', '2022-09-25 14:55:27', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('165', 'PUBLISHMENT', '3', '164', '新增广告物料', 'NODE', 'icon-settings', 'publishment.material.create', 'publishment.material.create,publishment.material.store', null, '1', '2022-09-25 14:55:44', '2022-09-25 14:55:44', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('166', 'PUBLISHMENT', '3', '164', '编辑广告物料', 'NODE', 'icon-settings', 'publishment.material.edit', 'publishment.material.edit,publishment.material.update', null, '1', '2022-09-25 14:56:03', '2022-09-25 14:56:03', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('167', 'PUBLISHMENT', '3', '164', '删除广告物料', 'NODE', 'icon-settings', 'publishment.material.destroy', 'publishment.material.destroy', null, '1', '2022-09-25 14:56:19', '2022-09-25 14:56:19', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('168', 'PUBLISHMENT', '3', '0', '账户管理', 'NAVIGATION', 'icon-settings', null, '', null, '10', '2022-09-26 23:17:37', '2022-09-27 00:46:45', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('169', 'PUBLISHMENT', '3', '168', '账户管理', 'PAGE', 'icon-settings', 'publishment.publisher.list', 'publishment.publisher.list', null, '1', '2022-09-26 23:18:03', '2022-09-26 23:18:03', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('170', 'PUBLISHMENT', '3', '169', '新增账户', 'NODE', 'icon-settings', 'publishment.publisher.create', 'publishment.publisher.create,publishment.publisher.store', null, '1', '2022-09-26 23:18:19', '2022-09-26 23:18:19', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('171', 'PUBLISHMENT', '3', '169', '编辑账户', 'NODE', 'icon-settings', 'publishment.publisher.edit', 'publishment.publisher.edit,publishment.publisher.update', null, '1', '2022-09-26 23:18:36', '2022-09-26 23:18:36', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('172', 'PUBLISHMENT', '3', '169', '删除账户', 'NODE', 'icon-settings', 'publishment.publisher.destroy', 'publishment.publisher.destroy', null, '1', '2022-09-26 23:18:54', '2022-09-26 23:18:54', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('173', 'PUBLISHMENT', '3', '169', '重置密码', 'NODE', 'icon-settings', 'publishment.publisher.password', 'publishment.publisher.password,publishment.publisher.updatePassword', null, '1', '2022-09-26 23:22:45', '2022-09-27 00:07:22', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('174', 'ADVERTISEMENT', '2', '0', '账户管理', 'NAVIGATION', 'icon-settings', null, '', null, '10', '2022-09-27 00:15:26', '2022-09-27 00:15:26', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('175', 'ADVERTISEMENT', '2', '174', '账户管理', 'PAGE', 'icon-settings', 'advertisement.advertiser.list', 'advertisement.advertiser.list', null, '10', '2022-09-27 00:15:54', '2022-09-27 00:20:32', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('176', 'ADVERTISEMENT', '2', '175', '新增账户', 'NODE', 'icon-settings', 'advertisement.advertiser.create', 'advertisement.advertiser.create,advertisement.advertiser.store', null, '1', '2022-09-27 00:16:24', '2022-09-27 00:35:48', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('177', 'ADVERTISEMENT', '2', '175', '编辑账户', 'NODE', 'icon-settings', 'advertisement.advertiser.edit', 'advertisement.advertiser.edit,advertisement.advertiser.update', null, '1', '2022-09-27 00:16:43', '2022-09-27 00:16:43', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('178', 'ADVERTISEMENT', '2', '175', '删除账户', 'NODE', 'icon-settings', 'advertisement.advertiser.destroy', 'advertisement.advertiser.destroy', null, '1', '2022-09-27 00:17:00', '2022-09-27 00:17:00', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('179', 'ADVERTISEMENT', '2', '175', '重置密码', 'NODE', 'icon-settings', 'advertisement.advertiser.password', 'advertisement.advertiser.password,advertisement.advertiser.updatePassword', null, '1', '2022-09-27 00:17:38', '2022-09-27 00:17:38', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('180', 'BACKEND', '1', '0', '广告主', 'NAVIGATION', 'icon-settings', null, '', null, '1', '2022-09-27 16:31:34', '2022-09-27 16:31:34', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('181', 'BACKEND', '1', '0', '流量主', 'NAVIGATION', 'icon-settings', null, '', null, '1', '2022-09-27 16:31:52', '2022-09-27 16:31:52', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('182', 'BACKEND', '1', '180', '广告主管理', 'PAGE', 'icon-settings', 'backend.advertisement.list', 'backend.advertisement.list', null, '1', '2022-09-27 16:32:16', '2022-09-27 16:32:16', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('183', 'BACKEND', '1', '182', '编辑广告主', 'NODE', 'icon-settings', 'backend.advertisement.edit', 'backend.advertisement.edit,backend.advertisement.update', null, '1', '2022-09-27 16:32:35', '2022-09-27 16:32:35', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('184', 'BACKEND', '1', '182', '删除广告主', 'NODE', 'icon-settings', 'backend.advertisement.destroy', 'backend.advertisement.destroy', null, '1', '2022-09-27 16:32:47', '2022-09-27 16:32:47', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('185', 'BACKEND', '1', '181', '流量主管理', 'PAGE', 'icon-settings', 'backend.publishment.list', 'backend.publishment.list', null, '1', '2022-09-27 16:33:17', '2022-09-27 16:33:17', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('186', 'BACKEND', '1', '185', '编辑流量主', 'NODE', 'icon-settings', 'backend.publishment.edit', 'backend.publishment.edit,backend.publishment.update', null, '1', '2022-09-27 16:33:34', '2022-09-27 16:33:34', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('187', 'BACKEND', '1', '185', '删除流量主', 'NODE', 'icon-settings', 'backend.publishment.destroy', 'backend.publishment.destroy', null, '1', '2022-09-27 16:33:54', '2022-09-27 16:33:54', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('188', 'BACKEND', '1', '180', '账户管理', 'PAGE', 'icon-settings', 'backend.advertiser.list', 'backend.advertiser.list', null, '1', '2022-09-27 17:28:23', '2022-09-27 17:28:23', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('189', 'BACKEND', '1', '188', '编辑账户', 'NODE', 'icon-settings', 'backend.advertiser.edit', 'backend.advertiser.edit,backend.advertiser.update', null, '1', '2022-09-27 17:30:47', '2022-09-27 17:30:47', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('190', 'BACKEND', '1', '188', '删除账户', 'NODE', 'icon-settings', 'backend.advertiser.destroy', 'backend.advertiser.destroy', null, '1', '2022-09-27 17:31:06', '2022-09-27 17:31:06', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('191', 'BACKEND', '1', '181', '账户管理', 'PAGE', 'icon-settings', 'backend.publisher.list', 'backend.publisher.list', null, '1', '2022-09-27 17:31:46', '2022-09-27 17:31:46', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('192', 'BACKEND', '1', '191', '编辑账户', 'NODE', 'icon-settings', 'backend.publisher.edit', 'backend.publisher.edit,backend.publisher.update', null, '1', '2022-09-27 17:32:04', '2022-09-27 17:32:04', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('193', 'BACKEND', '1', '191', '删除账户', 'NODE', 'icon-settings', 'backend.publisher.destroy', 'backend.publisher.destroy', null, '1', '2022-09-27 17:32:30', '2022-09-27 17:32:30', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('194', 'BACKEND', '1', '180', '广告计划', 'PAGE', 'icon-settings', 'backend.program.list', 'backend.program.list', null, '1', '2022-09-27 19:40:48', '2022-09-27 19:40:48', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('195', 'BACKEND', '1', '194', '编辑广告计划', 'NODE', 'icon-settings', 'backend.program.edit', 'backend.program.edit,backend.program.update', null, '1', '2022-09-27 19:41:07', '2022-09-27 19:41:07', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('196', 'BACKEND', '1', '194', '删除广告计划', 'NODE', 'icon-settings', 'backend.program.destroy', 'backend.program.destroy', null, '1', '2022-09-27 19:41:23', '2022-09-27 19:41:23', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('197', 'BACKEND', '1', '180', '广告单元', 'PAGE', 'icon-settings', 'backend.element.list', 'backend.element.list', null, '1', '2022-09-27 19:42:49', '2022-09-27 19:42:49', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('198', 'BACKEND', '1', '197', '编辑广告单元', 'NODE', 'icon-settings', 'backend.element.edit', 'backend.element.edit,backend.element.update', null, '1', '2022-09-27 19:43:13', '2022-09-27 19:43:13', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('199', 'BACKEND', '1', '197', '删除广告单元', 'NODE', 'icon-settings', 'backend.element.destroy', 'backend.element.destroy', null, '1', '2022-09-27 19:43:29', '2022-09-27 19:43:29', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('200', 'BACKEND', '1', '180', '广告创意', 'PAGE', 'icon-settings', 'backend.creative.list', 'backend.creative.list', null, '1', '2022-09-27 19:43:55', '2022-09-27 19:43:55', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('201', 'BACKEND', '1', '200', '编辑广告创意', 'NODE', 'icon-settings', 'backend.creative.edit', 'backend.creative.edit,backend.creative.update', null, '1', '2022-09-27 19:44:18', '2022-09-27 19:44:18', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('202', 'BACKEND', '1', '200', '删除广告创意', 'NODE', 'icon-settings', 'backend.creative.destroy', 'backend.creative.destroy', null, '1', '2022-09-27 19:44:37', '2022-09-27 19:44:37', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('203', 'BACKEND', '1', '181', '站点管理', 'PAGE', 'icon-settings', 'backend.site.list', 'backend.site.list', null, '1', '2022-09-27 19:45:56', '2022-09-27 19:45:56', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('204', 'BACKEND', '1', '203', '编辑站点', 'NODE', 'icon-settings', 'backend.site.edit', 'backend.site.edit,backend.site.update', null, '1', '2022-09-27 19:46:13', '2022-09-27 19:46:13', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('205', 'BACKEND', '1', '203', '删除站点', 'NODE', 'icon-settings', 'backend.site.destroy', 'backend.site.destroy', null, '1', '2022-09-27 19:46:32', '2022-09-27 19:46:32', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('206', 'BACKEND', '1', '181', '广告位管理', 'PAGE', 'icon-settings', 'backend.adsense.list', 'backend.adsense.list', null, '1', '2022-09-27 19:46:57', '2022-09-27 19:46:57', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('207', 'BACKEND', '1', '206', '编辑广告位', 'NODE', 'icon-settings', 'backend.adsense.edit', 'backend.adsense.edit,backend.adsense.update', null, '1', '2022-09-27 19:47:14', '2022-09-27 19:47:14', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('208', 'BACKEND', '1', '206', '删除广告位', 'NODE', 'icon-settings', 'backend.adsense.destroy', 'backend.adsense.destroy', null, '1', '2022-09-27 19:47:29', '2022-09-27 19:47:29', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('209', 'BACKEND', '1', '181', '广告物料', 'PAGE', 'icon-settings', 'backend.material.list', 'backend.material.list', null, '1', '2022-09-27 22:28:03', '2022-09-27 22:28:03', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('210', 'BACKEND', '1', '209', '编辑广告物料', 'NODE', 'icon-settings', 'backend.material.edit', 'backend.material.edit,backend.material.update', null, '1', '2022-09-27 22:28:32', '2022-09-27 22:28:32', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('211', 'BACKEND', '1', '209', '删除广告物料', 'NODE', 'icon-settings', 'backend.material.destroy', 'backend.material.destroy', null, '1', '2022-09-27 22:28:50', '2022-09-27 22:28:50', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('212', 'BACKEND', '1', '0', '资金管理', 'NAVIGATION', 'icon-settings', null, '', null, '1', '2022-09-28 14:13:41', '2022-09-28 14:13:41', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('213', 'BACKEND', '1', '212', '资金管理', 'PAGE', 'icon-settings', 'backend.deposit.list', 'backend.deposit.list', null, '1', '2022-09-28 14:14:08', '2022-09-28 14:14:08', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('214', 'BACKEND', '1', '213', '充值提现', 'NODE', 'icon-settings', 'backend.deposit.create', 'backend.deposit.create,backend.deposit.store', null, '1', '2022-09-28 14:16:14', '2022-09-28 14:16:14', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('215', 'BACKEND', '1', '213', '提现审核', 'NODE', 'icon-settings', 'backend.deposit.edit', 'backend.deposit.edit,backend.deposit.update', null, '1', '2022-09-28 14:16:51', '2022-09-28 14:16:51', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('216', 'BACKEND', '1', '213', '删除交易记录', 'NODE', 'icon-settings', 'backend.deposit.destroy', 'backend.deposit.destroy', null, '1', '2022-09-28 14:17:30', '2022-09-28 14:17:30', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('217', 'ADVERTISEMENT', '2', '0', '财务管理', 'NAVIGATION', 'icon-settings', null, '', null, '1', '2022-09-28 20:24:24', '2022-09-28 20:24:24', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('218', 'ADVERTISEMENT', '2', '217', '充值', 'PAGE', 'icon-settings', 'advertisement.deposit.recharge', 'advertisement.deposit.recharge,advertisement.deposit.store', null, '1', '2022-09-28 20:35:18', '2022-09-28 20:35:18', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('219', 'ADVERTISEMENT', '2', '217', '提现', 'PAGE', 'icon-settings', 'advertisement.deposit.withdraw', 'advertisement.deposit.withdraw,advertisement.deposit.update', null, '1', '2022-09-28 20:35:45', '2022-09-28 20:35:45', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('220', 'ADVERTISEMENT', '2', '217', '资金明细', 'PAGE', 'icon-settings', 'advertisement.deposit.list', 'advertisement.deposit.list', null, '1', '2022-09-28 20:36:37', '2022-09-28 20:36:37', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('221', 'PUBLISHMENT', '3', '0', '财务管理', 'NAVIGATION', 'icon-settings', null, '', null, '1', '2022-09-28 20:37:24', '2022-09-28 20:37:24', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('222', 'PUBLISHMENT', '3', '221', '充值', 'PAGE', 'icon-settings', 'publishment.deposit.recharge', 'publishment.deposit.recharge,publishment.deposit.store', null, '1', '2022-09-28 20:37:43', '2022-09-28 20:37:43', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('223', 'PUBLISHMENT', '3', '221', '提现', 'PAGE', 'icon-settings', 'publishment.deposit.withdraw', 'publishment.deposit.withdraw,publishment.deposit.update', null, '1', '2022-09-28 20:38:05', '2022-09-28 20:38:05', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('224', 'PUBLISHMENT', '3', '221', '资金明细', 'PAGE', 'icon-settings', 'publishment.deposit.list', 'publishment.deposit.list', null, '1', '2022-09-28 20:38:24', '2022-09-28 20:38:24', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('225', 'BACKEND', '1', '1', '系统配置', 'PAGE', 'icon-settings', 'backend.system.list', 'backend.system.list', null, '1', '2022-09-29 20:04:12', '2022-09-29 20:04:12', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('226', 'BACKEND', '1', '225', '新增配置', 'NODE', 'icon-settings', 'backend.system.create', 'backend.system.create,backend.system.store', null, '1', '2022-09-29 20:04:30', '2022-09-29 20:04:30', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('227', 'BACKEND', '1', '225', '编辑配置', 'NODE', 'icon-settings', 'backend.system.edit', 'backend.system.edit,backend.system.update', null, '1', '2022-09-29 20:04:44', '2022-09-29 20:04:44', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('228', 'BACKEND', '1', '225', '删除配置', 'NODE', 'icon-settings', 'backend.system.destroy', 'backend.system.destroy', null, '1', '2022-09-29 20:05:02', '2022-09-29 20:05:02', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('229', 'BACKEND', '1', '0', '报告', 'NAVIGATION', 'icon-settings', null, '', null, '1', '2022-10-10 20:44:29', '2022-10-10 20:44:29', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('230', 'ADVERTISEMENT', '2', '0', '报告', 'NAVIGATION', 'icon-settings', null, '', null, '1', '2022-10-10 20:44:41', '2022-10-10 20:44:41', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('231', 'PUBLISHMENT', '3', '0', '报告', 'NAVIGATION', 'icon-settings', null, '', null, '1', '2022-10-10 20:44:52', '2022-10-10 20:44:52', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('232', 'ADVERTISEMENT', '2', '230', '效果报告', 'PAGE', 'icon-settings', 'advertisement.vacation.list', 'advertisement.vacation.list', null, '1', '2022-10-10 21:04:08', '2022-10-10 21:04:08', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('233', 'PUBLISHMENT', '3', '231', '效果报告', 'PAGE', 'icon-settings', 'publishment.vacation.list', 'publishment.vacation.list', null, '1', '2022-10-10 21:04:36', '2022-10-10 22:52:35', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('234', 'PUBLISHMENT', '3', '231', '空闲报告', 'PAGE', 'icon-settings', 'publishment.visits.list', 'publishment.visits.list', null, '1', '2022-10-11 22:20:44', '2022-10-11 22:20:44', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('235', 'BACKEND', '1', '229', '展示报告', 'PAGE', 'icon-settings', 'backend.report.visits', 'backend.report.visits', null, '1', '2022-10-17 19:47:13', '2022-10-17 19:47:13', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('236', 'BACKEND', '1', '229', '点击报告', 'PAGE', 'icon-settings', 'backend.report.visitant', 'backend.report.visitant', null, '1', '2022-10-17 19:48:11', '2022-10-17 19:48:11', null, 'NORMAL');
INSERT INTO `im_policy` VALUES ('237', 'BACKEND', '1', '229', '费用报告', 'PAGE', 'icon-settings', 'backend.report.vacation', 'backend.report.vacation', null, '1', '2022-10-17 19:48:41', '2022-10-17 19:48:41', null, 'NORMAL');

-- ----------------------------
-- Table structure for `im_program`
-- ----------------------------
DROP TABLE IF EXISTS `im_program`;
CREATE TABLE `im_program` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `advertisement_id` bigint(20) unsigned DEFAULT '0',
  `device` enum('PC','MOBILE') DEFAULT 'PC' COMMENT '设备{PC:电脑}{MOBILE:移动端}',
  `limit` bigint(20) unsigned DEFAULT '0' COMMENT '日限额',
  `charge` bigint(20) unsigned DEFAULT '0' COMMENT '当日消费',
  `expire` date DEFAULT NULL COMMENT '日期',
  `title` varchar(255) DEFAULT NULL COMMENT '名称',
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `delete_time` datetime DEFAULT NULL,
  `state` enum('NORMAL','DISABLE') DEFAULT 'DISABLE' COMMENT '状态{NORMAL:正常}{DISABLE:禁用}',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COMMENT='广告计划';

-- ----------------------------
-- Records of im_program
-- ----------------------------
INSERT INTO `im_program` VALUES ('1', '1', 'PC', '100000', '0', null, '电脑端推广计划', '2022-09-21 12:07:07', '2022-10-02 19:24:17', null, 'NORMAL');
INSERT INTO `im_program` VALUES ('2', '1', 'MOBILE', '50000', '0', null, '移动端推广计划', '2022-09-21 12:08:12', '2022-09-21 12:19:26', null, 'NORMAL');
INSERT INTO `im_program` VALUES ('3', '2', 'PC', '100000', '0', null, '电脑端推广计划', '2022-09-21 12:07:07', '2022-09-21 18:13:23', null, 'NORMAL');
INSERT INTO `im_program` VALUES ('4', '2', 'MOBILE', '50000', '0', null, '移动端推广计划', '2022-09-21 12:08:12', '2022-09-21 12:19:26', null, 'NORMAL');
INSERT INTO `im_program` VALUES ('5', '10086', 'PC', '500000', '0', null, '电脑端推广计划', '2022-09-21 12:07:07', '2022-10-11 22:58:11', null, 'NORMAL');
INSERT INTO `im_program` VALUES ('6', '10086', 'MOBILE', '50000', '0', null, '移动端推广计划', '2022-09-21 12:08:12', '2022-09-21 12:19:26', null, 'NORMAL');
INSERT INTO `im_program` VALUES ('7', '10087', 'PC', '100000', '0', null, '电脑端推广计划', '2022-09-21 12:07:07', '2022-09-21 18:13:23', null, 'NORMAL');
INSERT INTO `im_program` VALUES ('8', '10087', 'MOBILE', '50000', '0', null, '移动端推广计划', '2022-09-21 12:08:12', '2022-09-21 12:19:26', null, 'NORMAL');
INSERT INTO `im_program` VALUES ('9', '10088', 'PC', '100000', '0', null, '电脑端推广计划', '2022-09-21 12:07:07', '2022-09-21 18:13:23', null, 'NORMAL');
INSERT INTO `im_program` VALUES ('10', '10088', 'MOBILE', '100000', '0', null, '移动端推广计划', '2022-09-21 12:08:12', '2022-09-27 20:03:35', null, 'NORMAL');

-- ----------------------------
-- Table structure for `im_publisher`
-- ----------------------------
DROP TABLE IF EXISTS `im_publisher`;
CREATE TABLE `im_publisher` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `publishment_id` bigint(20) unsigned DEFAULT NULL,
  `role_id` int(11) unsigned DEFAULT '0' COMMENT '角色编号',
  `role_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '角色名称',
  `usernick` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '昵称',
  `username` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '用户名',
  `userpass` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '密码',
  `usersalt` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '加盐',
  `register_ip` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '注册地址',
  `register_time` datetime DEFAULT NULL COMMENT '注册时间',
  `last_ip` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '登录地址',
  `last_time` datetime DEFAULT NULL COMMENT '登录时间',
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `delete_time` datetime DEFAULT NULL,
  `state` enum('NORMAL','DISABLE') COLLATE utf8mb4_unicode_ci DEFAULT 'DISABLE' COMMENT '状态{NORMAL:正常}{DISABLE:禁用}',
  PRIMARY KEY (`id`),
  KEY `role_id` (`role_id`) USING BTREE,
  KEY `username` (`username`(191)) USING BTREE,
  KEY `delete_time` (`delete_time`) USING BTREE,
  KEY `state` (`state`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='流量主账户';

-- ----------------------------
-- Records of im_publisher
-- ----------------------------
INSERT INTO `im_publisher` VALUES ('1', '1', '4', '管理员', 'admin', 'admin', 'bbad3eb5c50e5b21325f3a164cd5d29f', 'P0r9Ir', '127.0.0.1', '2022-01-01 18:00:00', '127.0.0.1', '2022-10-11 18:28:33', '2022-01-01 18:00:00', '2022-10-11 18:28:33', null, 'NORMAL');
INSERT INTO `im_publisher` VALUES ('2', '2', '4', '管理员', 'manager', 'manager', 'bbad3eb5c50e5b21325f3a164cd5d29f', 'P0r9Ir', '127.0.0.1', '2022-01-01 18:00:00', '127.0.0.1', '2022-10-11 18:26:17', '2022-01-01 18:00:00', '2022-10-11 18:26:17', null, 'NORMAL');
INSERT INTO `im_publisher` VALUES ('3', '2', '4', '管理员', 'member', 'member', '77ddc03c676f3489190ed595d0bb12f6', '1KZcof', '127.0.0.1', '2022-09-19 22:26:17', '127.0.0.1', '2022-09-19 22:39:52', '2022-09-19 22:26:17', '2022-09-19 22:39:52', null, 'NORMAL');
INSERT INTO `im_publisher` VALUES ('4', '10086', '4', '管理员', 'test1', 'test1', '8b83f309d6d229c45f617515622738e9', 'MlxuSZ', '127.0.0.1', '2022-09-19 22:26:17', '127.0.0.1', '2022-10-11 18:28:54', '2022-09-19 22:26:17', '2022-10-11 18:28:54', null, 'NORMAL');
INSERT INTO `im_publisher` VALUES ('5', '10087', '4', '管理员', 'test2', 'test2', '77ddc03c676f3489190ed595d0bb12f6', '1KZcof', '127.0.0.1', '2022-09-19 22:26:17', '127.0.0.1', '2022-09-19 22:26:17', '2022-09-19 22:26:17', '2022-09-19 22:26:17', null, 'NORMAL');
INSERT INTO `im_publisher` VALUES ('6', '10088', '4', '管理员', 'test3', 'test3', '4c18e64e51c32c8b5a734574a0ab29d4', '1KTajf', '127.0.0.1', '2022-09-19 22:26:17', '127.0.0.1', '2022-09-28 21:05:55', '2022-09-19 22:26:17', '2022-09-28 21:05:55', null, 'NORMAL');
INSERT INTO `im_publisher` VALUES ('7', '10086', '4', '管理员', 'test21', 'test21', 'ddb2d035f961f6851460e05bc8711126', 'JxwR1I', '127.0.0.1', '2022-09-26 23:48:13', '127.0.0.1', '2022-09-26 23:48:47', '2022-09-26 23:48:13', '2022-09-27 00:08:23', null, 'NORMAL');

-- ----------------------------
-- Table structure for `im_publishment`
-- ----------------------------
DROP TABLE IF EXISTS `im_publishment`;
CREATE TABLE `im_publishment` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `type` enum('COMPANY','PERSONAL') DEFAULT 'COMPANY' COMMENT '类型{COMPANY:公司}{PERSONAL:个人}',
  `name` varchar(255) DEFAULT NULL COMMENT '公司名称/真实姓名',
  `licence` varchar(255) DEFAULT NULL COMMENT '营业执照编号/身份证编号',
  `licence_image` varchar(255) DEFAULT NULL COMMENT '营业执照附件/身份证附件',
  `corporation` varchar(255) DEFAULT NULL COMMENT '联系人',
  `mobile` varchar(255) DEFAULT NULL COMMENT '联系电话',
  `mail` varchar(255) DEFAULT NULL COMMENT '邮箱',
  `total` bigint(20) unsigned DEFAULT '0' COMMENT '总额',
  `balance` bigint(20) DEFAULT '0' COMMENT '余额',
  `frozen` bigint(20) DEFAULT '0' COMMENT '冻结金额',
  `weight` bigint(20) DEFAULT '0' COMMENT '换量权重',
  `wallet` enum('ALIPAY','WECHAT','USDT') DEFAULT 'USDT' COMMENT '钱包类型{支付宝:ALIPAY}{微信:WECHAT}{USDT:USDT}',
  `acount` varchar(255) DEFAULT NULL COMMENT '钱包地址',
  `audit` enum('INIT','WAIT','SUCCESS','FAILURE','STOP') DEFAULT 'INIT' COMMENT '审核状态{INIT:初始化}{WAIT:待审核}{SUCCESS:成功}{FAILURE:失败}{STOP:终止合作}',
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `delete_time` datetime DEFAULT NULL,
  `state` enum('NORMAL','DISABLE') DEFAULT 'DISABLE' COMMENT '状态{NORMAL:正常}{DISABLE:禁用}',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10089 DEFAULT CHARSET=utf8mb4 COMMENT='流量主主体';

-- ----------------------------
-- Records of im_publishment
-- ----------------------------
INSERT INTO `im_publishment` VALUES ('1', 'PERSONAL', '公益', '91320200747189665N', 'https://via.placeholder.com/200x200/ac68e1/fff/200x200.png?text=200x200', '公益', '13627685999', 'admin@admin.com', '0', '0', '0', '10000', 'ALIPAY', 'alipay@alipay.com', 'SUCCESS', null, '2022-10-11 03:28:39', null, 'NORMAL');
INSERT INTO `im_publishment` VALUES ('2', 'COMPANY', '换量', '913202007471896652', 'https://via.placeholder.com/200x200/ac68e1/fff/200x200.png?text=200x200', '换量', '13627685999', 'manager@manager.com', '0', '0', '0', '10000', 'USDT', '0x000000', 'SUCCESS', '2022-09-19 22:26:17', '2022-10-11 17:35:33', null, 'NORMAL');
INSERT INTO `im_publishment` VALUES ('10086', 'COMPANY', 'test1', '913202007471896653', 'https://via.placeholder.com/200x200/ac68e1/fff/200x200.png?text=200x200', 'test1', '13627685999', 'test1@test.com', '0', '0', '0', '100', 'USDT', '0x000000', 'SUCCESS', '2022-09-19 22:26:17', '2022-10-11 22:58:11', null, 'NORMAL');
INSERT INTO `im_publishment` VALUES ('10087', 'COMPANY', 'test2', '913202007471896654', 'https://via.placeholder.com/200x200/ac68e1/fff/200x200.png?text=200x200', 'test2', '13627685999', 'test2@test.com', '0', '0', '0', '100', 'USDT', '0x000000', 'SUCCESS', '2022-09-19 22:26:17', '2022-10-02 23:44:28', null, 'NORMAL');
INSERT INTO `im_publishment` VALUES ('10088', 'COMPANY', 'test3', '913202007471896655', 'https://via.placeholder.com/200x200/ac68e1/fff/200x200.png?text=200x200', 'test3', '13627685999', 'test3@test.com', '0', '0', '0', '100', 'USDT', '0x000000', 'SUCCESS', '2022-09-19 22:26:17', '2022-10-02 23:44:28', null, 'NORMAL');

-- ----------------------------
-- Table structure for `im_role`
-- ----------------------------
DROP TABLE IF EXISTS `im_role`;
CREATE TABLE `im_role` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `module_namespace` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '标识符',
  `module_id` int(11) unsigned DEFAULT '0' COMMENT '所属模块',
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '角色名称',
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '备注',
  `policies` longtext COLLATE utf8mb4_unicode_ci COMMENT '策略集合',
  `sorting` int(11) unsigned DEFAULT '1' COMMENT '排序',
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `delete_time` datetime DEFAULT NULL,
  `state` enum('NORMAL','DISABLE') COLLATE utf8mb4_unicode_ci DEFAULT 'DISABLE' COMMENT '状态{NORMAL:正常}{DISABLE:禁用}',
  PRIMARY KEY (`id`),
  KEY `module_namespace` (`module_namespace`(191),`state`) USING BTREE,
  KEY `module_id` (`module_id`,`state`) USING BTREE,
  KEY `sorting` (`sorting`,`state`) USING BTREE,
  KEY `delete_time` (`delete_time`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='角色';

-- ----------------------------
-- Records of im_role
-- ----------------------------
INSERT INTO `im_role` VALUES ('1', 'BACKEND', '1', '超级管理员', null, '110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,128,129,130,131,141,142,143,144,182,183,184,185,186,187,188,189,190,191,192,193,194,195,196,197,198,199,200,201,202,203,204,205,206,207,208,209,210,211,213,214,215,216,225,226,227,228,235,236,237', '1', '2022-08-23 17:37:54', '2022-09-29 20:05:11', null, 'NORMAL');
INSERT INTO `im_role` VALUES ('2', 'BACKEND', '1', '管理员', null, '118,119,120,122,123,124', '1', '2022-08-23 18:05:37', '2022-08-23 22:48:28', null, 'NORMAL');
INSERT INTO `im_role` VALUES ('3', 'ADVERTISEMENT', '2', '管理员', null, '175,176,177,178,179,151,152,153,154,155,156,157,158,159,160,161,162,218,219,220,232', '1', '2022-09-15 17:53:34', '2022-10-10 21:04:47', null, 'NORMAL');
INSERT INTO `im_role` VALUES ('4', 'PUBLISHMENT', '3', '管理员', null, '133,134,135,136,137,138,139,140,146,147,148,149,164,165,166,167,169,170,171,172,173,222,223,224,233,234', '1', '2022-09-15 17:53:43', '2022-10-11 22:20:54', null, 'NORMAL');

-- ----------------------------
-- Table structure for `im_role_policy`
-- ----------------------------
DROP TABLE IF EXISTS `im_role_policy`;
CREATE TABLE `im_role_policy` (
  `role_id` int(11) unsigned NOT NULL DEFAULT '0',
  `policy_id` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`role_id`,`policy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='角色策略';

-- ----------------------------
-- Records of im_role_policy
-- ----------------------------
INSERT INTO `im_role_policy` VALUES ('1', '110');
INSERT INTO `im_role_policy` VALUES ('1', '111');
INSERT INTO `im_role_policy` VALUES ('1', '112');
INSERT INTO `im_role_policy` VALUES ('1', '113');
INSERT INTO `im_role_policy` VALUES ('1', '114');
INSERT INTO `im_role_policy` VALUES ('1', '115');
INSERT INTO `im_role_policy` VALUES ('1', '116');
INSERT INTO `im_role_policy` VALUES ('1', '117');
INSERT INTO `im_role_policy` VALUES ('1', '118');
INSERT INTO `im_role_policy` VALUES ('1', '119');
INSERT INTO `im_role_policy` VALUES ('1', '120');
INSERT INTO `im_role_policy` VALUES ('1', '121');
INSERT INTO `im_role_policy` VALUES ('1', '122');
INSERT INTO `im_role_policy` VALUES ('1', '123');
INSERT INTO `im_role_policy` VALUES ('1', '124');
INSERT INTO `im_role_policy` VALUES ('1', '125');
INSERT INTO `im_role_policy` VALUES ('1', '126');
INSERT INTO `im_role_policy` VALUES ('1', '128');
INSERT INTO `im_role_policy` VALUES ('1', '129');
INSERT INTO `im_role_policy` VALUES ('1', '130');
INSERT INTO `im_role_policy` VALUES ('1', '131');
INSERT INTO `im_role_policy` VALUES ('1', '141');
INSERT INTO `im_role_policy` VALUES ('1', '142');
INSERT INTO `im_role_policy` VALUES ('1', '143');
INSERT INTO `im_role_policy` VALUES ('1', '144');
INSERT INTO `im_role_policy` VALUES ('1', '182');
INSERT INTO `im_role_policy` VALUES ('1', '183');
INSERT INTO `im_role_policy` VALUES ('1', '184');
INSERT INTO `im_role_policy` VALUES ('1', '185');
INSERT INTO `im_role_policy` VALUES ('1', '186');
INSERT INTO `im_role_policy` VALUES ('1', '187');
INSERT INTO `im_role_policy` VALUES ('1', '188');
INSERT INTO `im_role_policy` VALUES ('1', '189');
INSERT INTO `im_role_policy` VALUES ('1', '190');
INSERT INTO `im_role_policy` VALUES ('1', '191');
INSERT INTO `im_role_policy` VALUES ('1', '192');
INSERT INTO `im_role_policy` VALUES ('1', '193');
INSERT INTO `im_role_policy` VALUES ('1', '194');
INSERT INTO `im_role_policy` VALUES ('1', '195');
INSERT INTO `im_role_policy` VALUES ('1', '196');
INSERT INTO `im_role_policy` VALUES ('1', '197');
INSERT INTO `im_role_policy` VALUES ('1', '198');
INSERT INTO `im_role_policy` VALUES ('1', '199');
INSERT INTO `im_role_policy` VALUES ('1', '200');
INSERT INTO `im_role_policy` VALUES ('1', '201');
INSERT INTO `im_role_policy` VALUES ('1', '202');
INSERT INTO `im_role_policy` VALUES ('1', '203');
INSERT INTO `im_role_policy` VALUES ('1', '204');
INSERT INTO `im_role_policy` VALUES ('1', '205');
INSERT INTO `im_role_policy` VALUES ('1', '206');
INSERT INTO `im_role_policy` VALUES ('1', '207');
INSERT INTO `im_role_policy` VALUES ('1', '208');
INSERT INTO `im_role_policy` VALUES ('1', '209');
INSERT INTO `im_role_policy` VALUES ('1', '210');
INSERT INTO `im_role_policy` VALUES ('1', '211');
INSERT INTO `im_role_policy` VALUES ('1', '213');
INSERT INTO `im_role_policy` VALUES ('1', '214');
INSERT INTO `im_role_policy` VALUES ('1', '215');
INSERT INTO `im_role_policy` VALUES ('1', '216');
INSERT INTO `im_role_policy` VALUES ('1', '225');
INSERT INTO `im_role_policy` VALUES ('1', '226');
INSERT INTO `im_role_policy` VALUES ('1', '227');
INSERT INTO `im_role_policy` VALUES ('1', '228');
INSERT INTO `im_role_policy` VALUES ('1', '235');
INSERT INTO `im_role_policy` VALUES ('1', '236');
INSERT INTO `im_role_policy` VALUES ('1', '237');
INSERT INTO `im_role_policy` VALUES ('2', '118');
INSERT INTO `im_role_policy` VALUES ('2', '119');
INSERT INTO `im_role_policy` VALUES ('2', '120');
INSERT INTO `im_role_policy` VALUES ('2', '122');
INSERT INTO `im_role_policy` VALUES ('2', '123');
INSERT INTO `im_role_policy` VALUES ('2', '124');
INSERT INTO `im_role_policy` VALUES ('3', '151');
INSERT INTO `im_role_policy` VALUES ('3', '152');
INSERT INTO `im_role_policy` VALUES ('3', '153');
INSERT INTO `im_role_policy` VALUES ('3', '154');
INSERT INTO `im_role_policy` VALUES ('3', '155');
INSERT INTO `im_role_policy` VALUES ('3', '156');
INSERT INTO `im_role_policy` VALUES ('3', '157');
INSERT INTO `im_role_policy` VALUES ('3', '158');
INSERT INTO `im_role_policy` VALUES ('3', '159');
INSERT INTO `im_role_policy` VALUES ('3', '160');
INSERT INTO `im_role_policy` VALUES ('3', '161');
INSERT INTO `im_role_policy` VALUES ('3', '162');
INSERT INTO `im_role_policy` VALUES ('3', '175');
INSERT INTO `im_role_policy` VALUES ('3', '176');
INSERT INTO `im_role_policy` VALUES ('3', '177');
INSERT INTO `im_role_policy` VALUES ('3', '178');
INSERT INTO `im_role_policy` VALUES ('3', '179');
INSERT INTO `im_role_policy` VALUES ('3', '218');
INSERT INTO `im_role_policy` VALUES ('3', '219');
INSERT INTO `im_role_policy` VALUES ('3', '220');
INSERT INTO `im_role_policy` VALUES ('3', '232');
INSERT INTO `im_role_policy` VALUES ('4', '133');
INSERT INTO `im_role_policy` VALUES ('4', '134');
INSERT INTO `im_role_policy` VALUES ('4', '135');
INSERT INTO `im_role_policy` VALUES ('4', '136');
INSERT INTO `im_role_policy` VALUES ('4', '137');
INSERT INTO `im_role_policy` VALUES ('4', '138');
INSERT INTO `im_role_policy` VALUES ('4', '139');
INSERT INTO `im_role_policy` VALUES ('4', '140');
INSERT INTO `im_role_policy` VALUES ('4', '146');
INSERT INTO `im_role_policy` VALUES ('4', '147');
INSERT INTO `im_role_policy` VALUES ('4', '148');
INSERT INTO `im_role_policy` VALUES ('4', '149');
INSERT INTO `im_role_policy` VALUES ('4', '164');
INSERT INTO `im_role_policy` VALUES ('4', '165');
INSERT INTO `im_role_policy` VALUES ('4', '166');
INSERT INTO `im_role_policy` VALUES ('4', '167');
INSERT INTO `im_role_policy` VALUES ('4', '169');
INSERT INTO `im_role_policy` VALUES ('4', '170');
INSERT INTO `im_role_policy` VALUES ('4', '171');
INSERT INTO `im_role_policy` VALUES ('4', '172');
INSERT INTO `im_role_policy` VALUES ('4', '173');
INSERT INTO `im_role_policy` VALUES ('4', '222');
INSERT INTO `im_role_policy` VALUES ('4', '223');
INSERT INTO `im_role_policy` VALUES ('4', '224');
INSERT INTO `im_role_policy` VALUES ('4', '233');
INSERT INTO `im_role_policy` VALUES ('4', '234');

-- ----------------------------
-- Table structure for `im_site`
-- ----------------------------
DROP TABLE IF EXISTS `im_site`;
CREATE TABLE `im_site` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `publishment_id` bigint(20) unsigned DEFAULT NULL COMMENT '流量主编号',
  `industry_id` bigint(20) unsigned DEFAULT NULL COMMENT '行业编号',
  `title` varchar(255) DEFAULT NULL COMMENT '标题',
  `protocol` varchar(255) DEFAULT NULL COMMENT '协议',
  `domain` varchar(255) DEFAULT NULL COMMENT '域名',
  `description` text COMMENT '描述',
  `hash` varchar(255) DEFAULT NULL COMMENT '签名',
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `delete_time` datetime DEFAULT NULL,
  `state` enum('NORMAL','DISABLE') DEFAULT 'DISABLE' COMMENT '状态{NORMAL:正常}{DISABLE:禁用}',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COMMENT='站点';

-- ----------------------------
-- Records of im_site
-- ----------------------------
INSERT INTO `im_site` VALUES ('1', '10086', '3', '电影网站', 'http://', 'v2.me.yunduanchongqing.com/', null, '53d6a6cc4eb4c151e80ad577802286d8', '2022-09-19 16:28:29', '2022-09-19 16:28:29', null, 'NORMAL');
INSERT INTO `im_site` VALUES ('2', '10087', '3', '电影网站', 'http://', 'v2.me.yunduanchongqing.com/', null, '53d6a6cc4eb4c151e80ad577802286d8', '2022-09-24 12:50:14', '2022-09-24 12:50:14', null, 'NORMAL');
INSERT INTO `im_site` VALUES ('3', '10088', '3', '电影网站', 'http://', 'v2.me.yunduanchongqing.com/', null, '53d6a6cc4eb4c151e80ad577802286d8', '2022-09-24 12:50:14', '2022-09-27 22:18:23', null, 'NORMAL');

-- ----------------------------
-- Table structure for `im_size`
-- ----------------------------
DROP TABLE IF EXISTS `im_size`;
CREATE TABLE `im_size` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `pid` bigint(20) unsigned DEFAULT '0' COMMENT '父级编号',
  `title` varchar(255) DEFAULT NULL COMMENT '名称',
  `width` int(11) unsigned DEFAULT '0' COMMENT '宽度',
  `height` int(11) unsigned DEFAULT '0' COMMENT '高度',
  `description` text COMMENT '描述',
  `device` varchar(255) DEFAULT NULL COMMENT '设备{PC:电脑}{MOBILE:移动端}',
  `type` varchar(255) DEFAULT NULL COMMENT '展现类型{SINGLE:单图}{MULTIGRAPH:多图}{POPUP:弹窗}{FLOAT:悬浮}{COUPLET:对联}',
  `sorting` int(11) unsigned DEFAULT '1' COMMENT '排序',
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `delete_time` datetime DEFAULT NULL,
  `state` enum('NORMAL','DISABLE') DEFAULT 'DISABLE' COMMENT '状态{NORMAL:正常}{DISABLE:禁用}',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COMMENT='广告尺寸';

-- ----------------------------
-- Records of im_size
-- ----------------------------
INSERT INTO `im_size` VALUES ('1', '0', '方形和矩形', null, null, null, '', '', '1', '2022-09-17 15:25:40', '2022-09-27 12:41:36', null, 'NORMAL');
INSERT INTO `im_size` VALUES ('2', '0', '摩天大楼', null, null, null, '', '', '1', '2022-09-17 15:25:49', '2022-09-17 15:25:49', null, 'NORMAL');
INSERT INTO `im_size` VALUES ('3', '0', '横幅', null, null, null, '', '', '3', '2022-09-17 15:25:58', '2022-09-17 22:18:06', null, 'NORMAL');
INSERT INTO `im_size` VALUES ('4', '0', '半横幅', null, null, null, '', '', '2', '2022-09-17 15:27:08', '2022-09-17 22:18:00', null, 'NORMAL');
INSERT INTO `im_size` VALUES ('5', '1', '小方形', '200', '200', null, 'PC', 'SINGLE,MULTIGRAPH', '1', '2022-09-17 15:27:39', '2022-09-30 04:05:21', null, 'NORMAL');
INSERT INTO `im_size` VALUES ('6', '1', '竖向矩形', '240', '400', null, 'PC', 'SINGLE,MULTIGRAPH', '1', '2022-09-17 15:28:18', '2022-09-17 21:45:24', null, 'NORMAL');
INSERT INTO `im_size` VALUES ('7', '1', '正方形', '250', '250', null, 'PC', 'SINGLE,MULTIGRAPH', '1', '2022-09-17 15:28:29', '2022-09-17 21:45:31', null, 'NORMAL');
INSERT INTO `im_size` VALUES ('8', '1', '三倍宽屏', '250', '360', null, 'PC', 'SINGLE,MULTIGRAPH', '1', '2022-09-17 15:28:42', '2022-09-17 21:45:37', null, 'NORMAL');
INSERT INTO `im_size` VALUES ('9', '1', '内插矩形', '300', '250', null, 'PC,MOBILE', 'SINGLE,MULTIGRAPH,POPUP,FLOAT', '1', '2022-09-17 15:28:52', '2022-09-17 22:24:20', null, 'NORMAL');
INSERT INTO `im_size` VALUES ('10', '1', '大矩形', '336', '280', null, 'PC', 'SINGLE,MULTIGRAPH,POPUP,FLOAT', '1', '2022-09-17 15:29:03', '2022-09-17 22:24:27', null, 'NORMAL');
INSERT INTO `im_size` VALUES ('11', '1', 'Netboard', '580', '400', null, 'PC', 'SINGLE,MULTIGRAPH,POPUP', '1', '2022-09-17 15:29:22', '2022-09-17 21:44:46', null, 'NORMAL');
INSERT INTO `im_size` VALUES ('12', '2', '摩天大楼', '120', '600', null, 'PC', 'SINGLE,MULTIGRAPH,COUPLET', '1', '2022-09-17 15:29:47', '2022-09-17 22:20:00', null, 'NORMAL');
INSERT INTO `im_size` VALUES ('13', '2', '宽幅摩天大楼', '160', '600', null, 'PC', 'SINGLE,MULTIGRAPH,COUPLET', '1', '2022-09-17 15:30:02', '2022-09-17 22:20:06', null, 'NORMAL');
INSERT INTO `im_size` VALUES ('14', '2', '半版广告', '300', '600', null, 'PC', 'SINGLE,MULTIGRAPH,COUPLET', '1', '2022-09-17 15:30:16', '2022-09-17 22:20:11', null, 'NORMAL');
INSERT INTO `im_size` VALUES ('15', '2', '纵向', '300', '1050', null, 'PC', 'SINGLE,MULTIGRAPH,COUPLET', '1', '2022-09-17 15:30:32', '2022-09-17 22:20:32', null, 'NORMAL');
INSERT INTO `im_size` VALUES ('16', '3', '横幅', '486', '60', null, 'PC', 'SINGLE,MULTIGRAPH', '1', '2022-09-17 15:30:57', '2022-09-17 15:30:57', null, 'NORMAL');
INSERT INTO `im_size` VALUES ('17', '3', '页首横幅', '728', '90', null, 'PC', 'SINGLE,MULTIGRAPH', '1', '2022-09-17 15:31:11', '2022-09-17 15:31:11', null, 'NORMAL');
INSERT INTO `im_size` VALUES ('18', '3', '顶部横幅', '930', '180', null, 'PC', 'SINGLE,MULTIGRAPH', '1', '2022-09-17 15:31:25', '2022-09-17 15:31:25', null, 'NORMAL');
INSERT INTO `im_size` VALUES ('19', '3', '大型页首横幅', '970', '90', null, 'PC', 'SINGLE,MULTIGRAPH', '1', '2022-09-17 15:31:39', '2022-09-17 15:31:39', null, 'NORMAL');
INSERT INTO `im_size` VALUES ('20', '3', '广告牌', '970', '250', null, 'PC', 'SINGLE,MULTIGRAPH', '1', '2022-09-17 15:31:51', '2022-09-17 15:31:51', null, 'NORMAL');
INSERT INTO `im_size` VALUES ('21', '3', '全景', '980', '120', null, 'PC', 'SINGLE,MULTIGRAPH', '1', '2022-09-17 15:32:02', '2022-09-27 12:42:20', null, 'NORMAL');
INSERT INTO `im_size` VALUES ('22', '4', '小型半横幅', '300', '50', null, 'PC,MOBILE', 'SINGLE,MULTIGRAPH', '1', '2022-09-17 15:32:18', '2022-09-17 22:12:32', null, 'NORMAL');
INSERT INTO `im_size` VALUES ('23', '4', '中型半横幅', '320', '50', null, 'PC,MOBILE', 'SINGLE,MULTIGRAPH', '1', '2022-09-17 15:32:30', '2022-09-17 22:12:37', null, 'NORMAL');
INSERT INTO `im_size` VALUES ('24', '4', '大型半横幅', '320', '100', null, 'PC,MOBILE', 'SINGLE,MULTIGRAPH', '1', '2022-09-17 15:32:44', '2022-09-17 22:12:42', null, 'NORMAL');

-- ----------------------------
-- Table structure for `im_system`
-- ----------------------------
DROP TABLE IF EXISTS `im_system`;
CREATE TABLE `im_system` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL COMMENT '名称',
  `key` varchar(255) DEFAULT NULL COMMENT '键名',
  `value` text COMMENT '键值',
  `type` enum('TEXT','RADIO','SELECT','CHECKBOX','TEXTAREA','DATETIMEPICKER','DATEPICKER','TIMEPICKER','FILE','STATIC') DEFAULT 'TEXT' COMMENT '类型',
  `options` text COMMENT '配置',
  `description` text COMMENT '描述',
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `delete_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COMMENT='系统配置';

-- ----------------------------
-- Records of im_system
-- ----------------------------
INSERT INTO `im_system` VALUES ('1', '平台总额', 'TOTAL_AMOUNT', '0.0000', 'STATIC', null, null, '2022-09-29 20:26:12', '2022-10-11 22:58:11', null);
INSERT INTO `im_system` VALUES ('2', '平台默认提成比例', 'RATE', '20', 'TEXT', '20', null, '2022-10-02 21:34:19', '2022-10-02 21:34:19', null);
INSERT INTO `im_system` VALUES ('3', '广告展示开启队列', 'ANALYSIS_QUEUE_REVIEW', 'normal', 'RADIO', '{\"normal\":\"开启\",\"disable\":\"关闭\"}', null, '2022-10-01 12:44:37', '2022-10-11 21:37:07', null);
INSERT INTO `im_system` VALUES ('4', '广告点击开启队列', 'ANALYSIS_QUEUE_LOCATION', 'normal', 'RADIO', '{\"normal\":\"开启\",\"disable\":\"关闭\"}', null, '2022-10-01 12:45:39', '2022-10-11 21:37:09', null);
INSERT INTO `im_system` VALUES ('5', '广告展示队列延迟时间(秒)', 'ANALYSIS_QUEUE_REVIEW_TIME', '15', 'TEXT', '300', null, '2022-10-11 12:04:39', '2022-10-11 21:34:58', null);
INSERT INTO `im_system` VALUES ('6', '广告点击队列延迟时间(秒)', 'ANALYSIS_QUEUE_LOCATION_TIME', '30', 'TEXT', '300', null, '2022-10-11 12:05:18', '2022-10-11 21:36:54', null);
INSERT INTO `im_system` VALUES ('7', 'CPV有效间隔(秒)', 'CPV_MIN_TIME', '120', 'TEXT', '300', null, '2022-10-02 18:26:09', '2022-10-11 23:08:05', null);
INSERT INTO `im_system` VALUES ('8', 'CPC有效间隔(秒)', 'CPC_MIN_TIME', '300', 'TEXT', '300', null, '2022-10-10 20:29:11', '2022-10-11 23:08:00', null);
INSERT INTO `im_system` VALUES ('9', '广告关闭时效(秒)', 'AD_CLOSE_TIME', '1200', 'TEXT', '1800', null, '2022-09-30 01:05:06', '2022-09-30 03:04:53', null);
INSERT INTO `im_system` VALUES ('10', '换量广告效果评估方式', 'EXCHANGE_CHARGING_TYPE', 'cpc', 'RADIO', '{\"cpc\":\"CPC\",\"cpv\":\"CPV\"}', '换量广告按CPV或者CPC方式计算流量主有效，全局有效', '2022-10-09 13:03:34', '2022-10-11 03:33:30', null);
INSERT INTO `im_system` VALUES ('11', 'CPA功能开关', 'CPA_STATE', 'disable', 'RADIO', '{\"normal\":\"开启\",\"disable\":\"关闭\"}', null, '2022-10-10 23:24:59', '2022-10-11 16:23:08', null);
INSERT INTO `im_system` VALUES ('12', 'CPS功能开关', 'CPS_STATE', 'disable', 'RADIO', '{\"normal\":\"开启\",\"disable\":\"关闭\"}', null, '2022-10-10 23:25:25', '2022-10-11 16:23:05', null);
INSERT INTO `im_system` VALUES ('13', '广告主注册开关', 'ADVERTISEMENT_REGISTRATION', 'disable', 'RADIO', '{\"normal\":\"开启\",\"disable\":\"关闭\"}', null, '2022-09-30 00:00:27', '2022-09-30 00:23:05', null);
INSERT INTO `im_system` VALUES ('14', '流量主注册开关', 'PUBLISHMENT_REGISTRATION', 'disable', 'RADIO', '{\"normal\":\"开启\",\"disable\":\"关闭\"}', null, '2022-09-30 00:00:27', '2022-09-30 00:24:04', null);
INSERT INTO `im_system` VALUES ('15', '固定占位符广告主键', 'VACANT_FIXED_PUBLISHMENT_ID', '1', 'TEXT', '1', '多个之间用逗号隔开', '2022-09-30 01:10:24', '2022-09-30 01:12:36', null);
INSERT INTO `im_system` VALUES ('16', '换量广告主键', 'VACANT_EXCHANGE_PUBLISHMENT_ID', '2', 'TEXT', '2', '多个之间用逗号隔开', '2022-09-30 01:11:00', '2022-09-30 01:12:31', null);
INSERT INTO `im_system` VALUES ('17', '广告主注册默认角色组', 'ADVERTISEMENT_ROLE_ID', '3', 'TEXT', '3', null, '2022-09-30 01:11:54', '2022-09-30 01:11:54', null);
INSERT INTO `im_system` VALUES ('18', '流量主注册默认角色组', 'PUBLISHMENT_ROLE_ID', '4', 'TEXT', '4', null, '2022-09-30 01:12:06', '2022-09-30 01:12:06', null);
INSERT INTO `im_system` VALUES ('19', 'CPC最低限额', 'CPC_MIN_AMOUNT', '5.00', 'TEXT', null, null, '2022-09-29 22:56:49', '2022-10-11 16:29:14', null);
INSERT INTO `im_system` VALUES ('20', 'CPM最低限额', 'CPM_MIN_AMOUNT', '25.00', 'TEXT', '25', null, '2022-09-29 23:29:58', '2022-09-29 23:29:58', null);
INSERT INTO `im_system` VALUES ('21', 'CPV最低限额', 'CPV_MIN_AMOUNT', '25.00', 'TEXT', '25.00', null, '2022-10-11 11:53:20', '2022-10-11 11:53:20', null);
INSERT INTO `im_system` VALUES ('22', 'CPA最低限额', 'CPA_MIN_AMOUNT', '25.00', 'TEXT', '25', null, '2022-09-29 23:30:29', '2022-09-29 23:30:29', null);
INSERT INTO `im_system` VALUES ('23', 'CPS最低限额', 'CPS_MIN_AMOUNT', '25.00', 'TEXT', '25', null, '2022-09-29 23:30:57', '2022-09-29 23:30:57', null);
INSERT INTO `im_system` VALUES ('24', '最低提现金额', 'WITHDRAW_MIN_AMOUNT', '50.00', 'TEXT', '50.00', null, '2022-09-29 23:33:33', '2022-09-29 23:33:33', null);
INSERT INTO `im_system` VALUES ('25', '无效广告物料地址', 'UNAVAILABLE_LOCATION', 'javascript:void(0);', 'TEXT', 'javascript:void(0);', null, '2022-09-30 01:15:11', '2022-09-30 01:15:11', null);
INSERT INTO `im_system` VALUES ('26', '无效广告物料图片', 'UNAVAILABLE_IMAGE', 'https://via.placeholder.com/400x400?text=unavailable', 'FILE', 'https://via.placeholder.com/400x400?text=unavailable', null, '2022-09-30 01:15:39', '2022-09-30 01:15:39', null);
INSERT INTO `im_system` VALUES ('27', '无效广告物料展示回调', 'UNAVAILABLE_CALLBACK', 'test', 'TEXT', 'test', null, '2022-09-30 01:16:07', '2022-09-30 01:16:07', null);
INSERT INTO `im_system` VALUES ('28', '广告联盟网址', 'UNION_LINK', 'https://union.baidu.com/?adnetwork', 'TEXT', null, null, '2022-09-30 01:13:07', '2022-09-30 01:13:07', null);
INSERT INTO `im_system` VALUES ('29', '网站首页配置', 'HOME', '{\"url\":\"home.index\",\"name\":\"广告联盟\",\"title\":\"广告联盟 - title\",\"keywords\":\"keywords\",\"description\":\"description\",\"logo\":\"assets\\/logo.png\",\"navigation\":[{\"title\":\"首页\",\"url\":\"home.index\"},{\"title\":\"广告主\",\"url\":\"advertisement.index\"},{\"title\":\"网站主\",\"url\":\"publishment.index\"},{\"title\":\"演示\",\"url\":[\"home.index\",\"\\/demo\"]}],\"sliders\":[{\"background\":\"assets\\/3f4ca78567bdb98e942eeb371d07d475.png\",\"title\":\"精准投放 让您值得信赖的联盟\",\"content\":[\"广告主是广告活动的发布者，是在网上销售或宣传自己产品和服务的商家，是联盟营销广告的提供者。\",\"按照地域、时间等多种定向方式投放，实现广告精准投放。\"],\"name\":\"广告主平台\",\"url\":\"advertisement.index\"},{\"background\":\"assets\\/7f55a27afd448a1a9ad41df1a5e0ff21.png\",\"title\":\"丰富多样的广告资源 完善的佣金结算系统\",\"content\":[\"提供多种合作模式及广告模式，有效地保证广告的高点击率，帮助网站主的实现变现能力。\",\"网站主可以采用多种灵活的方式获取收益，让您获得更多高额回报。\"],\"name\":\"网站主平台\",\"url\":\"publishment.index\"}],\"advertisement\":{\"title\":\"广告主入驻广告联盟流程\",\"content\":[\"进入注册页面，马上加盟\",\"成为会员，后台充值\",\"新建联盟推广计划，上传广告物料\",\"随时进入后台查询推广效果\"],\"name\":\"广告主平台\",\"url\":\"advertisement.index\",\"image\":\"assets\\/20221013180433.png\",\"service\":{\"title\":\"广告主平台优势\",\"desc\":\"广告主是广告活动的发布者，是在网上销售或宣传自己产品和服务的商家，是联盟营销广告的提供者。\",\"list\":[{\"icon\":\"fa fa-film\",\"title\":\"精准投放\",\"content\":[\"按照地域、时间等多种定向方式投放，实现广告精准投放。\"]},{\"icon\":\"fa fa-camera\",\"title\":\"反作弊及效果跟踪\",\"content\":[\"反作弊采用智能过滤拦截，针对各种异常数据进行过滤拦截。\"]},{\"icon\":\"fa fa-bullhorn\",\"title\":\"让您值得信赖的联盟\",\"content\":[\"为您提供详细数据报告，满足您的监控需求。\"]},{\"icon\":\"fa fa-music\",\"title\":\"强大的技术力量支持\",\"content\":[\"拥有独特的技术优势，强大的技术团队保证了系统的正常运行。\"]},{\"icon\":\"fa fa-magic\",\"title\":\"诚信为本\",\"content\":[\"诚信为本，做站长最值得信赖的网站广告联盟。\"]},{\"icon\":\"fa fa-bar-chart\",\"title\":\"全天候专业服务\",\"content\":[\"觉见技术问题提供专业的解决方案\"]}]}},\"publishment\":{\"title\":\"网站主入驻广告联盟流程\",\"content\":[\"进入注册页面，马上加盟\",\"成为会员，后台登记网址\",\"领取广告代码，参与联盟推广计划\",\"广告上线获取丰厚佣金，随时进入后台查询收益\"],\"name\":\"广告主平台\",\"url\":\"publishment.index\",\"image\":\"assets\\/20221013180501.png\",\"service\":{\"title\":\"网站主平台优势\",\"desc\":\"提供多种合作模式及广告模式，有效地保证广告的高点击率，帮助网站主的实现变现能力。\",\"list\":[{\"icon\":\"fa fa-film\",\"title\":\"丰富多样的广告资源\",\"content\":[\"严格把控广告质量，确保最佳用户体验，提升站长的收入。\"]},{\"icon\":\"fa fa-camera\",\"title\":\"详细精准的数据统计\",\"content\":[\"为站长提供透明、实时的流量数据和收入报表，站长可随时监测。\"]},{\"icon\":\"fa fa-bullhorn\",\"title\":\"完善的佣金结算系统\",\"content\":[\"网站主可以采用多种灵活的方式获取收益，让您获得更多高额回报。\"]},{\"icon\":\"fa fa-music\",\"title\":\"强大的技术力量支持\",\"content\":[\"拥有独特的技术优势，强大的技术团队保证了系统的正常运行。\"]},{\"icon\":\"fa fa-magic\",\"title\":\"诚信为本\",\"content\":[\"诚信为本，做站长最值得信赖的网站广告联盟。\"]},{\"icon\":\"fa fa-bar-chart\",\"title\":\"全天候专业服务\",\"content\":[\"觉见技术问题提供专业的解决方案\"]}]}},\"faq\":{\"title\":\"常见问题\",\"desc\":\"联盟常见问题及换量广告问题\",\"list\":[{\"title\":\"联盟支持哪些广告形式?\",\"content\":\"平台支持单图、多图、弹窗、悬浮、对联等广告形式。\"},{\"title\":\"联盟支持哪些广告模式?\",\"content\":\"为站长提供CPC、CPM、CPV、CPA、CPS多种广告模式，大大提升了网站主的变现能力。\"},{\"title\":\"联盟支持哪些投放设备?\",\"content\":\"平台支持PC及移动端等投放设备。\"},{\"title\":\"什么是换量广告?\",\"content\":\"换量广告是联盟平台为网站主提供的一项创新广告形式，当广告位匹配不到合适的广告资源时，将展示换量广告资源。\"}]}}', 'TEXTAREA', '{\"url\":\"home.index\",\"name\":\"广告联盟\",\"title\":\"广告联盟\",\"keywords\":\"keywords\",\"description\":\"description\",\"logo\":\"assets\\/logo.png\",\"navigation\":[{\"title\":\"首页\",\"url\":\"home.index\"},{\"title\":\"广告主\",\"url\":\"advertisement.index\"},{\"title\":\"网站主\",\"url\":\"publishment.index\"},{\"title\":\"演示\",\"url\":[\"home.index\",\"\\/demo\"]}],\"sliders\":[{\"background\":\"assets\\/3f4ca78567bdb98e942eeb371d07d475.png\",\"title\":\"精准投放 让您值得信赖的联盟\",\"content\":[\"广告主是广告活动的发布者，是在网上销售或宣传自己产品和服务的商家，是联盟营销广告的提供者。\",\"按照地域、时间等多种定向方式投放，实现广告精准投放。\"],\"name\":\"广告主平台\",\"url\":\"advertisement.index\"},{\"background\":\"assets\\/7f55a27afd448a1a9ad41df1a5e0ff21.png\",\"title\":\"丰富多样的广告资源 完善的佣金结算系统\",\"content\":[\"提供多种合作模式及广告模式，有效地保证广告的高点击率，帮助网站主的实现变现能力。\",\"网站主可以采用多种灵活的方式获取收益，让您获得更多高额回报。\"],\"name\":\"网站主平台\",\"url\":\"publishment.index\"}],\"advertisement\":{\"title\":\"广告主入驻广告联盟流程\",\"content\":[\"进入注册页面，马上加盟\",\"成为会员，后台充值\",\"新建联盟推广计划，上传广告物料\",\"随时进入后台查询推广效果\"],\"name\":\"广告主平台\",\"url\":\"advertisement.index\",\"image\":\"assets\\/20221013180433.png\",\"service\":{\"title\":\"广告主平台优势\",\"desc\":\"广告主是广告活动的发布者，是在网上销售或宣传自己产品和服务的商家，是联盟营销广告的提供者。\",\"list\":[{\"icon\":\"fa fa-film\",\"title\":\"精准投放\",\"content\":[\"按照地域、时间等多种定向方式投放，实现广告精准投放。\"]},{\"icon\":\"fa fa-camera\",\"title\":\"反作弊及效果跟踪\",\"content\":[\"反作弊采用智能过滤拦截，针对各种异常数据进行过滤拦截。\"]},{\"icon\":\"fa fa-bullhorn\",\"title\":\"让您值得信赖的联盟\",\"content\":[\"为您提供详细数据报告，满足您的监控需求。\"]},{\"icon\":\"fa fa-music\",\"title\":\"强大的技术力量支持\",\"content\":[\"拥有独特的技术优势，强大的技术团队保证了系统的正常运行。\"]},{\"icon\":\"fa fa-magic\",\"title\":\"诚信为本\",\"content\":[\"诚信为本，做站长最值得信赖的网站广告联盟。\"]},{\"icon\":\"fa fa-bar-chart\",\"title\":\"全天候专业服务\",\"content\":[\"觉见技术问题提供专业的解决方案\"]}]}},\"publishment\":{\"title\":\"网站主入驻广告联盟流程\",\"content\":[\"进入注册页面，马上加盟\",\"成为会员，后台登记网址\",\"领取广告代码，参与联盟推广计划\",\"广告上线获取丰厚佣金，随时进入后台查询收益\"],\"name\":\"广告主平台\",\"url\":\"publishment.index\",\"image\":\"assets\\/20221013180501.png\",\"service\":{\"title\":\"网站主平台优势\",\"desc\":\"提供多种合作模式及广告模式，有效地保证广告的高点击率，帮助网站主的实现变现能力。\",\"list\":[{\"icon\":\"fa fa-film\",\"title\":\"丰富多样的广告资源\",\"content\":[\"严格把控广告质量，确保最佳用户体验，提升站长的收入。\"]},{\"icon\":\"fa fa-camera\",\"title\":\"详细精准的数据统计\",\"content\":[\"为站长提供透明、实时的流量数据和收入报表，站长可随时监测。\"]},{\"icon\":\"fa fa-bullhorn\",\"title\":\"完善的佣金结算系统\",\"content\":[\"网站主可以采用多种灵活的方式获取收益，让您获得更多高额回报。\"]},{\"icon\":\"fa fa-music\",\"title\":\"强大的技术力量支持\",\"content\":[\"拥有独特的技术优势，强大的技术团队保证了系统的正常运行。\"]},{\"icon\":\"fa fa-magic\",\"title\":\"诚信为本\",\"content\":[\"诚信为本，做站长最值得信赖的网站广告联盟。\"]},{\"icon\":\"fa fa-bar-chart\",\"title\":\"全天候专业服务\",\"content\":[\"觉见技术问题提供专业的解决方案\"]}]}},\"faq\":{\"title\":\"常见问题\",\"desc\":\"联盟常见问题及换量广告问题\",\"list\":[{\"title\":\"联盟支持哪些广告形式?\",\"content\":\"平台支持单图、多图、弹窗、悬浮、对联等广告形式。\"},{\"title\":\"联盟支持哪些广告模式?\",\"content\":\"为站长提供CPC、CPM、CPV、CPA、CPS多种广告模式，大大提升了网站主的变现能力。\"},{\"title\":\"联盟支持哪些投放设备?\",\"content\":\"平台支持PC及移动端等投放设备。\"},{\"title\":\"什么是换量广告?\",\"content\":\"换量广告是联盟平台为网站主提供的一项创新广告形式，当广告位匹配不到合适的广告资源时，将展示换量广告资源。\"}]}}', null, '2022-10-13 21:59:46', '2022-10-13 22:04:43', null);
INSERT INTO `im_system` VALUES ('30', '倒计时配置', 'COMING_SOON', '{\"name\":\"广告联盟\",\"title\":\"广告联盟 - title\",\"keywords\":\"keywords\",\"description\":\"description\",\"logo\":\"assets\\/logo.png\",\"background\":\"assets\\/e218bb37a870cfde9d43cd8cd0379a32.png\",\"activist\":\"稍后访问\",\"moment\":\"系统升级\",\"date\":\"2022-12-31 23:59:59\",\"location\":\"home.index\"}', 'TEXTAREA', '{\"name\":\"广告联盟\",\"title\":\"广告联盟\",\"keywords\":\"keywords\",\"description\":\"description\",\"logo\":\"assets\\/logo.png\",\"background\":\"assets\\/e218bb37a870cfde9d43cd8cd0379a32.png\",\"activist\":\"稍后访问\",\"moment\":\"系统升级\",\"date\":\"2022-12-31 23:59:59\",\"location\":\"home.index\"}', null, '2022-10-13 21:57:47', '2022-10-13 22:04:58', null);
INSERT INTO `im_system` VALUES ('31', '倒计时开关', 'COMING_SOON_STATE', 'disable', 'RADIO', '{\"normal\":\"开启\",\"disable\":\"关闭\"}', null, '2022-10-13 22:01:23', '2022-10-13 22:07:08', null);
INSERT INTO `im_system` VALUES ('32', '防广告主刷广告位', 'FILTER_SECURITY_IP', 'normal', 'RADIO', '{\"normal\":\"开启\",\"disable\":\"关闭\"}', null, '2022-10-18 14:40:17', '2022-10-18 14:40:23', null);

-- ----------------------------
-- Table structure for `im_vacation`
-- ----------------------------
DROP TABLE IF EXISTS `im_vacation`;
CREATE TABLE `im_vacation` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `guid` varchar(255) DEFAULT NULL COMMENT '全局标识',
  `uuid` varchar(255) DEFAULT NULL COMMENT '用户表示',
  `ruid` varchar(255) DEFAULT NULL COMMENT '请求标识',
  `size_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `advertisement_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `program_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `element_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `creative_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `publishment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `site_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `channel_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `adsense_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `request_time` datetime DEFAULT NULL COMMENT '本地时间',
  `response_time` datetime DEFAULT NULL COMMENT '服务器时间',
  `type` enum('CPC','CPM','CPV','CPA','CPS') DEFAULT 'CPC' COMMENT '出价方式{CPC}{CPM}{CPV}{CPA}{CPS}',
  `origin_rate` bigint(20) unsigned DEFAULT '0',
  `rate` bigint(20) unsigned DEFAULT '0' COMMENT '出价',
  `ip` varchar(255) DEFAULT NULL,
  `time` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `delete_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='付费记录';

-- ----------------------------
-- Records of im_vacation
-- ----------------------------

-- ----------------------------
-- Table structure for `im_visitant`
-- ----------------------------
DROP TABLE IF EXISTS `im_visitant`;
CREATE TABLE `im_visitant` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `guid` varchar(255) DEFAULT NULL COMMENT '全局标识',
  `uuid` varchar(255) DEFAULT NULL COMMENT '用户表示',
  `ruid` varchar(255) DEFAULT NULL COMMENT '请求标识',
  `visits_id` bigint(20) unsigned DEFAULT '0',
  `vacation_id` bigint(20) unsigned DEFAULT '0',
  `size_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `advertisement_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `program_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `element_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `creative_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `publishment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `site_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `channel_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `adsense_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `material_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `request_time` datetime DEFAULT NULL COMMENT '本地时间',
  `response_time` datetime DEFAULT NULL COMMENT '服务器时间',
  `type` enum('SINGLE','MULTIGRAPH','POPUP','FLOAT','COUPLET','EXCHANGE','DEFAULT','UNION','FIXED','HIDDEN') DEFAULT 'SINGLE' COMMENT '展现类型{SINGLE:单图}{MULTIGRAPH:多图}{POPUP:弹窗}{FLOAT:悬浮}{COUPLET:对联}{EXCHANGE:显示换量广告}{DEFAULT:显示默认广告}{UNION:显示联盟广告}{FIXED:固定占位符}{HIDDEN:隐藏广告位}',
  `ip` varchar(255) DEFAULT NULL,
  `time` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `delete_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='广告物料点击记录';

-- ----------------------------
-- Records of im_visitant
-- ----------------------------

-- ----------------------------
-- Table structure for `im_visitor`
-- ----------------------------
DROP TABLE IF EXISTS `im_visitor`;
CREATE TABLE `im_visitor` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `guid` varchar(255) DEFAULT NULL COMMENT '用户全局标识',
  `uuid` varchar(255) DEFAULT NULL COMMENT '用户独立标识',
  `language` varchar(255) DEFAULT NULL COMMENT '语言',
  `platform` varchar(255) DEFAULT NULL COMMENT '操作系统',
  `device` enum('PC','MOBILE') DEFAULT 'PC' COMMENT '设备{PC:电脑}{MOBILE:移动端}',
  `screen_width` int(10) unsigned DEFAULT '0' COMMENT '设备屏幕宽度',
  `screen_height` int(10) unsigned DEFAULT '0' COMMENT '设备屏幕高度',
  `user_agent` varchar(255) DEFAULT NULL COMMENT '设备代理信息',
  `ip` varchar(255) DEFAULT NULL,
  `time` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `delete_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='设备';

-- ----------------------------
-- Records of im_visitor
-- ----------------------------

-- ----------------------------
-- Table structure for `im_visits`
-- ----------------------------
DROP TABLE IF EXISTS `im_visits`;
CREATE TABLE `im_visits` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `guid` varchar(255) DEFAULT NULL COMMENT '全局标识',
  `uuid` varchar(255) DEFAULT NULL COMMENT '用户表示',
  `ruid` varchar(255) DEFAULT NULL COMMENT '请求标识',
  `visitor_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '设备编号',
  `visitant_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '点击记录编号',
  `vacation_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '付费记录编号',
  `size_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `advertisement_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `program_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `element_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `creative_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `publishment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `site_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `channel_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `adsense_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `material_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `document_title` varchar(512) DEFAULT NULL COMMENT '所在标题',
  `document_referrer` varchar(512) DEFAULT NULL COMMENT '来源网址',
  `document_url` varchar(512) DEFAULT NULL COMMENT '所在网址',
  `width` varchar(255) DEFAULT NULL COMMENT '自定义宽度',
  `height` varchar(255) DEFAULT NULL COMMENT '自定义高度',
  `request_time` datetime DEFAULT NULL COMMENT '本地时间',
  `response_time` datetime DEFAULT NULL COMMENT '服务器时间',
  `type` enum('SINGLE','MULTIGRAPH','POPUP','FLOAT','COUPLET','EXCHANGE','DEFAULT','UNION','FIXED','HIDDEN') DEFAULT 'SINGLE' COMMENT '展现类型{SINGLE:单图}{MULTIGRAPH:多图}{POPUP:弹窗}{FLOAT:悬浮}{COUPLET:对联}{EXCHANGE:显示换量广告}{DEFAULT:显示默认广告}{UNION:显示联盟广告}{FIXED:固定占位符}{HIDDEN:隐藏广告位}',
  `ip` varchar(255) DEFAULT NULL,
  `time` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `delete_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='广告物料展示记录';

-- ----------------------------
-- Records of im_visits
-- ----------------------------
