<?php

namespace App\Repositories\Advertisement;

use App\Exceptions\RenderErrorResponseException;
use App\Models\Advertisement;
use App\Models\Advertiser;
use App\Models\Role;
use App\Repositories\Repository;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;

class AccountRepository extends Repository
{
    public function __construct(
        private readonly Advertiser $advertiser,
        private readonly Advertisement $advertisement,
        private readonly Role $role,
    )
    {
        //
    }

    public function login(Request $request)
    {
        $advertiser = $this->advertiser
            ->where('username', $request->get('username'))
            ->first();

        if (is_null($advertiser)) {
            throw new RenderErrorResponseException('用户名或密码有误');
        }

        if ($advertiser->state == 'disable') {
            throw new RenderErrorResponseException('账户已被禁用');
        }

        if (strcasecmp($advertiser->userpass, password($request->get('password'), $advertiser->usersalt))) {
            throw new RenderErrorResponseException('用户名或密码有误');
        }

        $advertiser->update([
            'last_ip' => $request->getClientIp(),
            'last_time' => get_time(),
        ]);

        $this->guard('advertiser')->login($advertiser);
    }

    public function logout(Request $request)
    {
        $this->guard('advertiser')->logout();
        app('request')->session()->invalidate();
    }

    public function signup(Request $request): array
    {
        $filter = [
            'type' => $this->advertisement->getType(),
        ];

        if (config('system.advertisement_registration', 'disable') == 'disable') {
            throw new RenderErrorResponseException('注册功能暂未开启');
        }

        return compact('filter');
    }

    public function register(Request $request)
    {
        $email = session($request->get('email'));

        if (strcasecmp($email, $request->get('code'))) {
            throw new RenderErrorResponseException('邮箱验证码无效');
        }

        $role = $this->role->find(config('system.advertisement_role_id'));

        if (is_null($role)) {
            throw new RenderErrorResponseException('默认角色组异常');
        }

        DB::beginTransaction();
        $advertisement = $this->advertisement->create([
            'type' => $request->get('type'),
            'mail' => $request->get('email'),
            'audit' => 'INIT',
            'state' => 'NORMAL',
        ]);

        if (is_null($advertisement)) {
            DB::rollBack();
            throw new RenderErrorResponseException('新增主体信息失败');
        }

        $usersalt = generate_string();
        $userpass = password($request->get('password'), $usersalt);

        $advertiser = $this->advertiser->create([
            'advertisement_id' => $advertisement->getKey(),
            'role_id' => $role->getAttribute('id'),
            'role_title' => $role->getAttribute('title'),
            'usernick' => $request->get('username'),
            'username' => $request->get('username'),
            'userpass' => $userpass,
            'usersalt' => $usersalt,
            'register_ip' => $request->getClientIp(),
            'register_time' => get_time(),
            'state' => 'NORMAL',
        ]);
        DB::commit();

        return $advertiser;
    }

    public function mail(Request $request)
    {
        $email = $request->get('email');

        $code = generate_number();

        session([
            $email => $code,
        ]);

        Mail::to($email)->send(new \App\Mail\Verification\Mail($code));
    }

}
